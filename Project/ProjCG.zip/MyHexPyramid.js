import { CGFobject } from '../lib/CGF.js';

export class MyHexPyramid extends CGFobject {
    constructor(scene, baseRadius, height) {
        super(scene);
        this.baseRadius = baseRadius;
        this.height = height;
        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];

        const sides = 6;
        const angle = (2 * Math.PI) / sides;

        // Base vertices
        for (let i = 0; i < sides; i++) {
            let x = Math.cos(i * angle) * this.baseRadius;
            let z = Math.sin(i * angle) * this.baseRadius;
            this.vertices.push(x, 0, z);
            this.normals.push(0, -1, 0);
            this.texCoords.push((x / (2 * this.baseRadius)) + 0.5, (z / (2 * this.baseRadius)) + 0.5);
        }

        // Base center
        this.vertices.push(0, 0, 0);
        this.normals.push(0, -1, 0);
        this.texCoords.push(0.5, 0.5);
        const baseCenterIndex = this.vertices.length / 3 - 1;

        // Base indices
        for (let i = 0; i < sides; i++) {
            const next = (i + 1) % sides;
            this.indices.push(baseCenterIndex, i, next);
        }

        // Side faces
        for (let i = 0; i < sides; i++) {
            const next = (i + 1) % sides;

            let x0 = Math.cos(i * angle) * this.baseRadius;
            let z0 = Math.sin(i * angle) * this.baseRadius;
            let x1 = Math.cos(next * angle) * this.baseRadius;
            let z1 = Math.sin(next * angle) * this.baseRadius;

            const idx0 = this.vertices.length / 3;
            this.vertices.push(x0, 0, z0);
            const idx1 = this.vertices.length / 3;
            this.vertices.push(x1, 0, z1);
            const idxApex = this.vertices.length / 3;
            this.vertices.push(0, this.height, 0);

            // Normals
            let normal = [
                (x0 + x1) / 2,
                this.baseRadius / this.height,
                (z0 + z1) / 2
            ];
            let length = Math.hypot(...normal);
            normal = normal.map(n => n / length);

            for (let j = 0; j < 3; j++) {
                this.normals.push(...normal);
            }

            // TexCoords
            this.texCoords.push(i / sides, 1);
            this.texCoords.push((i+1) / sides, 1);
            this.texCoords.push((i+0.5) / sides, 0);

            // Side indices
            this.indices.push(idx0, idxApex, idx1);
        }

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
}
