import { CGFobject, CGFappearance, CGFshader, CGFtexture } from '../lib/CGF.js';
import { MySphere } from "./MySphere.js";

export class MyPanorama extends CGFobject {
    constructor(scene, texture) {
        super(scene);
        this.scene = scene;
        this.texture = texture;        

        this.cloudTexture = new CGFtexture(scene, 'textures/cloudMap.jpg');
        this.cloudMaterial = new CGFappearance(scene);
        this.cloudMaterial.setTexture(this.cloudTexture);
        this.cloudMaterial.setTextureWrap('REPEAT', 'REPEAT');
        
        // Animation time tracking
        this.lastTime = 0;

        // Sky-Sphere
        this.sphere = new MySphere(scene, 32, 16, true);
        
        this.material = new CGFappearance(scene);
        this.material.setAmbient(0.7, 0.7, 0.7, 1.0);
        this.material.setDiffuse(1.0, 1.0, 1.0, 1.0);
        this.material.setSpecular(0.0, 0.0, 0.0, 1.0);
        this.material.setEmission(0.3, 0.3, 0.3, 1.0);
        this.material.setTexture(this.texture);
        this.material.setTextureWrap('REPEAT', 'REPEAT');

        this.initShader();
    }    
    
    initShader() {
        this.cloudShader = new CGFshader(this.scene.gl, 'shaders/skycloud.vert', 'shaders/skycloud.frag');
        this.cloudShader.setUniformsValues({
            uSampler2: 1,
            timeFactor: 0.0
        });
    }
    
    update(t) {
        if (this.lastTime === 0) {
            this.lastTime = t;
        }
        
        this.cloudShader.setUniformsValues({ 
            timeFactor: (t / 1000) % 1000
        }); 
    }

    display() {
        this.scene.pushMatrix();
        this.scene.translate(this.scene.camera.position[0], 
        this.scene.camera.position[1], 
        this.scene.camera.position[2]);        
        
        this.cloudMaterial.apply();
        this.cloudTexture.bind(1);
        
        this.scene.pushMatrix();
        const scaleFactor = 800;
        this.scene.scale(scaleFactor, scaleFactor, scaleFactor);
        this.material.apply();
        this.sphere.display();
        this.scene.popMatrix();
        this.scene.popMatrix();
    }
}
