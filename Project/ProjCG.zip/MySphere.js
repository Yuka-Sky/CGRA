import { CGFobject } from '../lib/CGF.js';

export class MySphere extends CGFobject {
    constructor(scene, slices, stacks, inverted=false) {
        super(scene);
        this.slices = slices;
        this.stacks = stacks;
        this.initBuffers(inverted);
    }

    initBuffers(invertFaces = false) {
        this.vertices = [];
        this.normals = [];
        this.indices = [];
        this.texCoords = [];
    
        const dTheta = Math.PI / (2 * this.stacks);
        const dPhi = (2 * Math.PI) / this.slices;
    
        for (let stack = -this.stacks; stack <= this.stacks; stack++) {
            let theta = stack * dTheta;
            let cosTheta = Math.cos(theta);
            let sinTheta = Math.sin(theta);
    
            for (let slice = 0; slice <= this.slices; slice++) {
                let phi = slice * dPhi;
                let cosPhi = Math.cos(phi);
                let sinPhi = Math.sin(phi);
    
                // Sphere coordinates (unit radius)
                let x = cosTheta * cosPhi;
                let y = sinTheta;
                let z = cosTheta * sinPhi;
    
                // Flip normals if inverting
                let normalX = invertFaces ? -x : x;
                let normalY = invertFaces ? -y : y;
                let normalZ = invertFaces ? -z : z;
    
                this.vertices.push(x, y, z);
                this.normals.push(normalX, normalY, normalZ);
                this.texCoords.push(slice / this.slices, 1 - (stack + this.stacks) / (2 * this.stacks));
            }
        }
    
        // Generate indices
        for (let stack = 0; stack < 2 * this.stacks; stack++) {
            for (let slice = 0; slice < this.slices; slice++) {
                let first = (stack * (this.slices + 1)) + slice;
                let second = first + this.slices + 1;
    
                if (invertFaces) {
                    this.indices.push(first + 1, second, first);
                    this.indices.push(first + 1, second + 1, second);
                } else {
                    this.indices.push(first, second, first + 1);
                    this.indices.push(second, second + 1, first + 1);
                }
            }
        }
    
        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }    
}
