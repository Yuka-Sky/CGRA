import {CGFobject} from '../../lib/CGF.js';
/**
 * MyLTriangle
 * @constructor
 * @param scene
 */
export class MyLTriangle extends CGFobject {
    constructor(scene) {
        super(scene);
        this.initBuffers();
    }
    
    initBuffers() {
        this.vertices = [
            0, 6, 0,	    //0
            -3.464, 0, 0,	//1
            0, 0, 0,	    //2

            0, 6, 0,	    //3
            -3.464, 0, 0,	//4
            0, 0, 0	        //5
        ];

        this.indices = [
            0, 1, 2,
            3, 5, 4
        ];

        this.normals = [
            0, 0, 1,   // 0
            0, 0, 1,   // 1
            0, 0, 1,   // 2
            0, 0, -1,  // 3
            0, 0, -1,  // 4
            0, 0, -1   // 5
        ];

        this.texCoords = [
            0, 0.5,
            0.5, 1,
            0, 1,

            0.5, 0,
            1, 0.5,
            1, 0
        ];
        
        this.primitiveType = this.scene.gl.TRIANGLES;

        this.initGLBuffers();
    }
}

