import {CGFobject} from '../../lib/CGF.js';
/**
 * MyParallelogram
 * @constructor
 * @param scene
 */
export class MyParallelogram extends CGFobject {
    constructor(scene) {
        super(scene);
        this.initBuffers();
    }
    
    initBuffers() {
        this.vertices = [
            0, 0, 0,	    //0
            2.23, 1.29, 0,	//1
            2.23, 2.69, 0,	//2
            0, 1.4, 0,      //3

            0, 0, 0,	    //4
            2.23, 1.29, 0,	//5
            2.23, 2.69, 0,	//6
            0, 1.4, 0		//7
        ];

        this.indices = [
            0, 1, 3,
            1, 2, 3,
            4, 7, 5,
            7, 6, 5
        ];

        this.normals = [
            0, 0, 1,  // 0
            0, 0, 1,  // 1
            0, 0, 1,  // 2
            0, 0, 1,  // 3
            0, 0, -1, // 4 (back)
            0, 0, -1, // 5 (back)
            0, 0, -1, // 6 (back)
            0, 0, -1  // 7 (back)
        ];

        this.texCoords = [
            0, 1,     // 0
            1, 0.5,   // 1
            1, 0,     // 2
            0, 0.5,   // 3

            1, 0,     // 4
            0.5, 1,   // 5
            0, 1,     // 6
            0.5, 0    // 7
        ];

        this.primitiveType = this.scene.gl.TRIANGLES;

        this.initGLBuffers();
    }
}

