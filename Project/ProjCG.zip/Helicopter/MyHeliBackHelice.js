import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyCylinder } from './MyCylinder.js';
import { MyCube } from './MyCube.js';

/**
 * MyHeliBackHelice
 * @constructor
 * @param scene
 * @param vel
 */
export class MyHeliBackHelice extends CGFobject {
    constructor(scene, vel) {
        super(scene);

        this.helices    = new MyCube(scene);
        this.pino       = new MyCylinder(scene, 15, 2, 0.6);
        this.centerbase = new MyCylinder(scene, 15, 1.2, 1);
        this.centerstripe = new MyCylinder(scene, 15, 0.5, 1.2);
        
        this.backHeliceRotation = 0;
        this.rotationSpeed = vel;


        this.heliMaterial = new CGFappearance(this.scene);
        this.heliMaterial.setAmbient(0.6, 0.6, 0.6, 1.0);
        this.heliMaterial.setDiffuse(0.6, 0.6, 0.6, 0.7); 
        this.heliMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.heliMaterial.setShininess(100);

        this.baseMaterial = new CGFappearance(this.scene);
        this.baseMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.baseMaterial.setDiffuse(0.3, 0.3, 0.3, 0.7); 
        this.baseMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.baseMaterial.setShininess(100);
    }

    updateTextures(heli_texture, metal_texture) {
        this.heli_texture = heli_texture;
        this.metal_texture = metal_texture;
        
        if (heli_texture) {
            this.heliMaterial.setTexture(heli_texture);
        }
        
        if (metal_texture) {
            this.baseMaterial.setTexture(metal_texture);
        }
    }

    display(){
        const gl = this.scene.gl;

        // Center base
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.pino.display();
        this.scene.popMatrix();

        // Rotate around Z axis
        this.scene.pushMatrix();
        this.scene.rotate(this.backHeliceRotation, 0, 1, 0);

        // Center
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.5, 0);
        this.centerbase.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.85, 0);
        this.centerstripe.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.85, 0);
        this.scene.scale(1.2, 0.2, 10);
        this.helices.display();
        this.scene.popMatrix();
        
        this.scene.popMatrix();
    }
    
    update(t) {
        this.backHeliceRotation += this.rotationSpeed * Math.abs(t);
        
        // Keep the angle within 2π to avoid large values over time //AI based
        if (this.backHeliceRotation > Math.PI * 2) {
            this.backHeliceRotation -= Math.PI * 2;
        }
    }    
}

