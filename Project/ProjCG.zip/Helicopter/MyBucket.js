import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyTrapezoide } from './MyTrapezoide.js';
import { MyQuad } from './MyQuad.js';
import { MyCylinder } from './MyCylinder.js';
import { MySphere } from '../MySphere.js';
/**
 * MyBucket
 * @constructor
 * @param scene
 */
export class MyBucket extends CGFobject {
    constructor(scene) {
        super(scene);
        
        this.rectangle   = new MyQuad(scene);
        this.trapez      = new MyTrapezoide(scene);
        this.fronpipe    = new MyCylinder(scene, 15, 20, 0.5);
        this.lateralpipe = new MyCylinder(scene, 15, 40, 0.5);
        this.ball        = new MySphere(scene, 15, 15, 0);
        
        this.hasWater = false;
        
        this.initMaterials();
    }
    initMaterials() {
        this.baseMaterial = new CGFappearance(this.scene);
        this.baseMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.baseMaterial.setDiffuse(0.3, 0.3, 0.3, 0.7); 
        this.baseMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.baseMaterial.setShininess(100);
        
        this.waterMaterial = new CGFappearance(this.scene);
        this.waterMaterial.setAmbient(0.1, 0.5, 0.6, 1.0);
        this.waterMaterial.setDiffuse(0.1, 0.5, 0.6, 1.0);
        this.waterMaterial.setSpecular(0.1, 0.5, 0.6, 1.0);
        this.waterMaterial.setShininess(15.0);
        this.waterMaterial.setEmission(0.2, 0.2, 0.2, 0.2);
    }
    
    setWaterStatus(hasWater) {
        this.hasWater = hasWater;
    }

    display(){
        const gl = this.scene.gl;

        if (this.hasWater) {
            this.waterMaterial.apply();
            this.scene.pushMatrix();
            this.scene.rotate(-Math.PI/2, 1, 0, 0);
            this.scene.translate(0, 0, 4.33);
            this.scene.scale(20, 40, 0);
            this.rectangle.display();
            this.scene.popMatrix();
        }

        // Front
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, 20);
        this.trapez.display();
        this.scene.popMatrix();

        // Back
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, -20);
        this.trapez.display();
        this.scene.popMatrix();

        // Left
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.rotate(Math.PI/6, 1, 0, 0);
        this.scene.translate(0, 3.75, 6.495);
        this.scene.scale(40, 10, 0);
        this.rectangle.display();
        this.scene.popMatrix();

        // Right
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.rotate(-Math.PI/6, 1, 0, 0);
        this.scene.translate(0, 3.75, -6.495);
        this.scene.scale(40, 10, 0);
        this.rectangle.display();
        this.scene.popMatrix();

        // Floor - left
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 1, 0, 0);
        this.scene.translate(-2.5, 0, -4.33);
        this.scene.scale(5, 40, 0);
        this.rectangle.display();
        this.scene.popMatrix();

        // Floor - right
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 1, 0, 0);
        this.scene.translate(2.5, 0, -4.33);
        this.scene.scale(5, 40, 0);
        this.rectangle.display();
        this.scene.popMatrix();
        
        // Long pipes - left
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 1, 0, 0);
        this.scene.translate(-10, -20, -4.33);
        this.lateralpipe.display();
        this.scene.popMatrix();
        
        // Long pipes - right
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 1, 0, 0);
        this.scene.translate(10, -20, -4.33);
        this.lateralpipe.display();
        this.scene.popMatrix();

        // Short pipes
        // 1
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 0, 0, 1);
        this.scene.translate(4.33, -10, 20);
        this.fronpipe.display();
        this.scene.popMatrix();
        // 2
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 0, 0, 1);
        this.scene.translate(4.33, -10, 7.3);
        this.fronpipe.display();
        this.scene.popMatrix();
        // 3
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 0, 0, 1);
        this.scene.translate(4.33, -10, -7.3);
        this.fronpipe.display();
        this.scene.popMatrix();
        // 4
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2, 0, 0, 1);
        this.scene.translate(4.33, -10, -20);
        this.fronpipe.display();
        this.scene.popMatrix();

        // Knots
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-10, 4.33, 20);
        this.scene.scale(0.7, 0.7, 0.7);
        this.ball.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(10, 4.33, 20);
        this.scene.scale(0.7, 0.7, 0.7);
        this.ball.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(10, 4.33, -20);
        this.scene.scale(0.7, 0.7, 0.7);
        this.ball.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-10, 4.33, -20);
        this.scene.scale(0.7, 0.7, 0.7);
        this.ball.display();
        this.scene.popMatrix();

    }    
}

