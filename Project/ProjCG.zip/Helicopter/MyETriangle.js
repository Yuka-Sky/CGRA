import {CGFobject} from '../../lib/CGF.js';
/**
 * MyETriangle
 * @constructor
 * @param {MyScene} scene
 * @param {Array} coords
 */
export class MyETriangle extends CGFobject {
    constructor(scene, coords) {
        super(scene);
        this.initBuffers();
        if (coords != undefined)
            this.updateTexCoords(coords);
    }
    
    initBuffers() {
        this.vertices = [
            0, 5.196, 0, //0
            -3, 0, 0,    //1
            3, 0, 0  	 //2
        ];

        this.indices = [
            0, 1, 2
        ];

        this.normals = [
            0, 0, 1,
            0, 0, 1,
            0, 0, 1
        ];

        this.texCoords = [
            1, 0,
            0, 0,
            0, 1
        ]

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
    
}

