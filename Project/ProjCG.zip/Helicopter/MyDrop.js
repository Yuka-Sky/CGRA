import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyCone2 } from './MyCone2.js';
import { MySphere } from '../MySphere.js';

/**
 * MyDrop
 * @constructor
 * @param scene
 */
export class MyDrop extends CGFobject {
    constructor(scene) {
        super(scene);

        this.body = new MySphere(scene, 30, 20, 0);
        this.top  = new MyCone2(scene, 30, 20);

        this.falling = false;
        this.positionY = 0;     // Current Y position of the water
        this.startY = 0;        // Starting Y position
        this.fallingSpeed = 40; // Speed of the water falling
        this.heliX = 0;         // X position of helicopter
        this.heliZ = 0;         // Z position of helicopter

        this.initMaterial();
    }
    
    initMaterial() {
        this.water = new CGFappearance(this.scene);
        this.water.setAmbient(0.1, 0.5, 0.6, 1.0);
        this.water.setDiffuse(0.1, 0.5, 0.6, 1.0);
        this.water.setSpecular(0.1, 0.5, 0.6, 1.0);
        this.water.setShininess(15.0);
    }
    
    startFalling(heliX, heliY, heliZ) {
        this.falling = true;
        this.positionY = heliY - 15; // Start from bottom of the bucket
        this.startY = this.positionY;
        this.heliX = heliX;
        this.heliZ = heliZ;
    }
    
    update(time) {
        if (!this.falling) return;
        this.positionY -= this.fallingSpeed * time;
        
        if (this.positionY < -3) {
            this.falling = false;
        }
    }

    display(){
        const gl = this.scene.gl;

        this.water.apply();
        if (this.falling) {

            // Update the position of every water drops
            this.scene.pushMatrix();
            this.scene.translate(this.heliX, this.positionY, this.heliZ);
            this.scene.scale(0.2, 0.2, 0.2);

            // Main drop - 100%
            this.scene.pushMatrix();
            this.scene.translate(0, 0, 0);
            this.scene.scale(10, 10, 10);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(0, 5, 0);
            this.scene.scale(8.66, 15, 8.66);
            this.top.display();
            this.scene.popMatrix();

            // Drop 2 - 75%
            this.scene.pushMatrix();
            this.scene.translate(-5, 6, 19);
            this.scene.scale(7.5, 7.5, 7.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(-5, 9.75, 19);
            this.scene.scale(6.495, 11.25, 6.495);
            this.top.display();
            this.scene.popMatrix();

            // Drop 3 - 75%
            this.scene.pushMatrix();
            this.scene.translate(7, -9, -22);
            this.scene.scale(7.5, 7.5, 7.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(7, -5.25, -22);
            this.scene.scale(6.495, 11.25, 6.495);
            this.top.display();
            this.scene.popMatrix();

            // Drop 4 - 50%
            this.scene.pushMatrix();
            this.scene.translate(13, 14, 15);
            this.scene.scale(5, 5, 5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(13, 16.5, 15);
            this.scene.scale(4.33, 7.5, 4.33);
            this.top.display();
            this.scene.popMatrix();

            // Drop 5 - 50%
            this.scene.pushMatrix();
            this.scene.translate(-13, -7, -15);
            this.scene.scale(5, 5, 5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(-13, -4.5, -15);
            this.scene.scale(4.33, 7.5, 4.33);
            this.top.display();
            this.scene.popMatrix();

            // Drop 6 - 50%
            this.scene.pushMatrix();
            this.scene.translate(10, 9, -7);
            this.scene.scale(5, 5, 5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(10, 11.5, -7);
            this.scene.scale(4.33, 7.5, 4.33);
            this.top.display();
            this.scene.popMatrix();

            // Drop 7 - 25%
            this.scene.pushMatrix();
            this.scene.translate(10, -10, 6);
            this.scene.scale(2.5, 2.5, 2.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(10, -8.75, 6);
            this.scene.scale(2.165, 3.75, 2.165);
            this.top.display();
            this.scene.popMatrix();

            // Drop 8 - 25%
            this.scene.pushMatrix();
            this.scene.translate(-10, 10, 6);
            this.scene.scale(2.5, 2.5, 2.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(-10, 11.25, 6);
            this.scene.scale(2.165, 3.75, 2.165);
            this.top.display();
            this.scene.popMatrix();

            // Drop 9 - 25%
            this.scene.pushMatrix();
            this.scene.translate(5, -3, 23);
            this.scene.scale(2.5, 2.5, 2.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(5, -1.75, 23);
            this.scene.scale(2.165, 3.75, 2.165);
            this.top.display();
            this.scene.popMatrix();

            this.scene.pushMatrix();
            // Drop 10 - 25%
            this.scene.pushMatrix();
            this.scene.translate(-3, 13, -18);
            this.scene.scale(2.5, 2.5, 2.5);
            this.body.display();
            this.scene.popMatrix();
            
            this.scene.pushMatrix();
            this.scene.translate(-3, 14.25, -18);
            this.scene.scale(2.165, 3.75, 2.165);
            this.top.display();
            this.scene.popMatrix();

            this.scene.popMatrix();
        }

        this.scene.setDefaultAppearance();
    }    
}