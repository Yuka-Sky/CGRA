import {CGFobject} from '../../lib/CGF.js';
/**
 * MyTrapezoide
 * @constructor
 * @param scene
 */
export class MyTrapezoide extends CGFobject {
    constructor(scene) {
        super(scene);
        this.initBuffers();
    }
    
    initBuffers() {
        this.vertices = [
            -10, 4.33, 0,	    //0
            -5, -4.33, 0,	    //1
            5, -4.33, 0,	    //2
            10, 4.33, 0,        //3

            -10, 4.33, 0,	    //4
            -5, -4.33, 0,	    //5
            5, -4.33, 0,	    //6
            10, 4.33, 0         //7
        ];

        this.indices = [
            0, 1, 3,
            1, 2, 3,

            4, 7, 5,
            5, 7, 6
        ];

        this.normals = [
            0, 0, 1,   // 0
            0, 0, 1,   // 1
            0, 0, 1,   // 2
            0, 0, 1,   // 3
            0, 0, -1,  // 4
            0, 0, -1,  // 5
            0, 0, -1,  // 6
            0, 0, -1   // 7
        ];

        this.texCoords = [
            1, 0,
            0, 0,
            0, 1,
            1, 1
        ];

        this.primitiveType = this.scene.gl.TRIANGLES;

        this.initGLBuffers();
    }
}

