import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyCylinder } from './MyCylinder.js';
import { MyQuad } from "./MyQuad.js";
import { MyQuarterCylinder } from './MyQuarterCylinder.js';
import { MyHeliTail } from './MyHeliTail.js';

/**
 * MyHeliBody
 * @constructor
 * @param scene
 */
export class MyHeliBody extends CGFobject {
    constructor(scene) {
        super(scene);

        // Cabin
        this.heliCabin = new MyQuad(scene);
        // Windshield
        this.cabinWindow = new MyQuarterCylinder(scene, 15, 10, 10);
        // Base
        this.longPipe = new MyCylinder(scene, 15, 28, 1);
        this.shortPipe = new MyCylinder(scene, 15, 5, 0.75);

        this.tail = new MyHeliTail(scene);

        this.initMaterials();
    }
    
    initMaterials() {
        this.heliMaterial = new CGFappearance(this.scene);
        this.heliMaterial.setAmbient(0.6, 0.6, 0.6, 1.0);
        this.heliMaterial.setDiffuse(0.6, 0.6, 0.6, 0.7); 
        this.heliMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.heliMaterial.setShininess(100);

        this.windowMaterial = new CGFappearance(this.scene);
        this.windowMaterial.setAmbient(0.3, 0.3, 0.3, 1.0);
        this.windowMaterial.setDiffuse(0.1, 0.1, 0.9, 0.7); 
        this.windowMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.windowMaterial.setShininess(100);

        this.baseMaterial = new CGFappearance(this.scene);
        this.baseMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.baseMaterial.setDiffuse(0.3, 0.3, 0.3, 0.7); 
        this.baseMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.baseMaterial.setShininess(100);
    }

    updateTextures(heli_texture, glass_texture, metal_texture) {
        this.heli_texture = heli_texture;
        this.glass_texture = glass_texture;
        this.metal_texture = metal_texture;
        
        if (heli_texture) {
            this.heliMaterial.setTexture(heli_texture);
        }
        
        if (glass_texture) {
            this.windowMaterial.setTexture(glass_texture);
        }

        if (metal_texture) {
            this.baseMaterial.setTexture(metal_texture);
        }
        
        if (this.tail) {
            this.tail.updateTextures(heli_texture);
        }
    }

    display(){
        const gl = this.scene.gl;

        // CABIN ----------------------------------
        // Right
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-5, 10.5, 0);
        this.scene.rotate(-Math.PI / 2, 0, 1, 0);
        this.scene.scale(20, 10, 1);
        this.heliCabin.display();
        this.scene.popMatrix();
        // Left
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(5, 10.5, 0);
        this.scene.rotate(Math.PI / 2, 0, 1, 0);
        this.scene.scale(20, 10, 1);
        this.heliCabin.display();
        this.scene.popMatrix();
        // Bottom
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 5.5, 0);
        this.scene.rotate(Math.PI / 2, 1, 0, 0);
        this.scene.scale(10, 20, 1);
        this.heliCabin.display();
        this.scene.popMatrix();
        // Top
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 15.5, 0);
        this.scene.rotate(-Math.PI / 2, 1, 0, 0);
        this.scene.scale(10, 20, 1);
        this.heliCabin.display();
        this.scene.popMatrix();
        // Back
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 10.5, 10);
        this.scene.rotate(Math.PI, 0, 1, 0);
        this.scene.scale(10, 10, 1);
        this.scene.translate(0, 0, 20);
        this.heliCabin.display();
        this.scene.popMatrix();
        // Top support
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 15, 0);
        this.shortPipe.display();
        this.scene.popMatrix();
        //-----------------------------------------
        // WINDSHIELD -----------------------------
        this.windowMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(5, 5.5, 10);
        this.scene.rotate(Math.PI / 2, 0, 0, 1);
        this.cabinWindow.display();
        this.scene.popMatrix();
        //-----------------------------------------
        // BASE -----------------------------------
        // Right side
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-5, 1, -14);
        this.scene.rotate(Math.PI / 2, 1, 0, 0);
        this.longPipe.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-5, 1, -6.5);
        this.scene.rotate(-Math.PI / 18, 0, 0, 1);
        this.shortPipe.display();
        this.scene.popMatrix();
        
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(-5, 1, 6.5);
        this.scene.rotate(-Math.PI / 18, 0, 0, 1);
        this.shortPipe.display();
        this.scene.popMatrix();

        // Left side
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(5, 1, -14);
        this.scene.rotate(Math.PI / 2, 1, 0, 0);
        this.longPipe.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(5, 1, -6.5);
        this.scene.rotate(Math.PI / 18, 0, 0, 1);
        this.shortPipe.display();
        this.scene.popMatrix();
        
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(5, 1, 6.5);
        this.scene.rotate(Math.PI / 18, 0, 0, 1);
        this.shortPipe.display();
        this.scene.popMatrix();
        //-----------------------------------------

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 2.5+3.536, -10);
        this.scene.rotate(-Math.PI/2, 1, 0, 0);
        this.scene.scale(1.55, 4, 2.6);
        this.tail.display();
        this.scene.popMatrix();

        this.scene.setDefaultAppearance();
    }    
}