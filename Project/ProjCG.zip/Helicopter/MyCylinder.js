import { CGFobject } from '../../lib/CGF.js';

export class MyCylinder extends CGFobject {
    constructor(scene, slices, height, radius) {
        super(scene);
        this.slices = slices;
        this.height = height;
        this.radius = radius;
        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];

        let angle = (2 * Math.PI) / this.slices;

        // Side vertices
        for (let i = 0; i <= this.slices; i++) {
            let x = Math.cos(i * angle) * this.radius;
            let z = Math.sin(i * angle) * this.radius;
            this.vertices.push(x, 0, z);
            this.normals.push(x, 0, z);
            this.texCoords.push(i / this.slices, 1);

            this.vertices.push(x, this.height, z);
            this.normals.push(x, 0, z);
            this.texCoords.push(i / this.slices, 0);
        }

        // Side indices
        for (let i = 0; i < this.slices; i++) {
            let base = i * 2;
            this.indices.push(base, base + 1, base + 2);
            this.indices.push(base + 1, base + 3, base + 2);
        }

        // Top face
        let topCenterIndex = this.vertices.length / 3;
        this.vertices.push(0, this.height, 0);
        this.normals.push(0, 1, 0);
        this.texCoords.push(0.5, 0.5);

        for (let i = 0; i <= this.slices; i++) {
            let x = Math.cos(i * angle) * this.radius;
            let z = Math.sin(i * angle) * this.radius;
            this.vertices.push(x, this.height, z);
            this.normals.push(0, 1, 0);
            this.texCoords.push(0.5 + (x / (2 * this.radius)), 0.5 + (z / (2 * this.radius)));

            if (i > 0) {
                this.indices.push(topCenterIndex, topCenterIndex + i + 1, topCenterIndex + i);
            }
        }

        // Bottom face
        let bottomCenterIndex = this.vertices.length / 3;
        this.vertices.push(0, 0, 0);
        this.normals.push(0, -1, 0);
        this.texCoords.push(0.5, 0.5);

        for (let i = 0; i <= this.slices; i++) {
            let x = Math.cos(i * angle) * this.radius;
            let z = Math.sin(i * angle) * this.radius;
            this.vertices.push(x, 0, z);
            this.normals.push(0, -1, 0);
            this.texCoords.push(0.5 + (x / (2 * this.radius)), 0.5 - (z / (2 * this.radius)));

            if (i > 0) {
                this.indices.push(bottomCenterIndex, bottomCenterIndex + i, bottomCenterIndex + i + 1);
            }
        }

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
}