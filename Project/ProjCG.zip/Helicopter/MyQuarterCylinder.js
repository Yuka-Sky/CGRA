import {CGFobject, CGFappearance} from '../../lib/CGF.js';

export class MyQuarterCylinder extends CGFobject {
    constructor(scene, slices, height, radius) {
        super(scene);
        this.slices = slices;
        this.height = height;
        this.radius = radius;
        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];

        const angleStep = (Math.PI / 2) / this.slices;

        // curved surface 
        for (let i = 0; i <= this.slices; i++) {
            const angle = i * angleStep;
            const x = Math.cos(angle) * this.radius;
            const z = Math.sin(angle) * this.radius;

            // bottom vertex
            this.vertices.push(x, 0, z);
            this.normals.push(x, 0, z);
            this.texCoords.push(i / this.slices, 1);

            // top vertex
            this.vertices.push(x, this.height, z);
            this.normals.push(x, 0, z);
            this.texCoords.push(i / this.slices, 0);
        }

        for (let i = 0; i < this.slices; i++) {
            const base = i * 2;
            this.indices.push(base, base + 1, base + 2); // triangle 1
            this.indices.push(base + 1, base + 3, base + 2); // triangle 2
        }

        // top cap
        const topCenterIndex = this.vertices.length / 3;
        this.vertices.push(0, this.height, 0);
        this.normals.push(0, 1, 0);
        this.texCoords.push(0.5, 0.5);

        for (let i = 0; i <= this.slices; i++) {
            const angle = i * angleStep;
            const x = Math.cos(angle) * this.radius;
            const z = Math.sin(angle) * this.radius;

            this.vertices.push(x, this.height, z);
            this.normals.push(0, 1, 0);
            this.texCoords.push(0.5 + x / (2 * this.radius), 0.5 - z / (2 * this.radius));
        }

        for (let i = 0; i < this.slices; i++) {
            this.indices.push(
                topCenterIndex,
                topCenterIndex + i + 2,
                topCenterIndex + i + 1
            );
        }

        // bottom cap
        const bottomCenterIndex = this.vertices.length / 3;
        this.vertices.push(0, 0, 0);
        this.normals.push(0, -1, 0);
        this.texCoords.push(0.5, 0.5);

        for (let i = 0; i <= this.slices; i++) {
            const angle = i * angleStep;
            const x = Math.cos(angle) * this.radius;
            const z = Math.sin(angle) * this.radius;

            this.vertices.push(x, 0, z);
            this.normals.push(0, -1, 0);
            this.texCoords.push(0.5 + x / (2 * this.radius), 0.5 + z / (2 * this.radius));
        }

        for (let i = 0; i < this.slices; i++) {
            this.indices.push(
                bottomCenterIndex,
                bottomCenterIndex + i + 1,
                bottomCenterIndex + i + 2
            );
        }

        // side flat faces
        // X=0 plane (Z-axis)
        const zPlaneBaseIndex = this.vertices.length / 3;
        
        // bottom-left corner
        this.vertices.push(0, 0, 0);
        this.normals.push(-1, 0, 0);
        this.texCoords.push(0, 1);
        
        // top-left corner
        this.vertices.push(0, this.height, 0);
        this.normals.push(-1, 0, 0);
        this.texCoords.push(0, 0);
        
        // bottom-right corner
        this.vertices.push(0, 0, this.radius);
        this.normals.push(-1, 0, 0);
        this.texCoords.push(1, 1);
        
        // top-right corner
        this.vertices.push(0, this.height, this.radius);
        this.normals.push(-1, 0, 0);
        this.texCoords.push(1, 0);
        
        this.indices.push(
            zPlaneBaseIndex, zPlaneBaseIndex + 2, zPlaneBaseIndex + 1,
            zPlaneBaseIndex + 2, zPlaneBaseIndex + 3, zPlaneBaseIndex + 1
        );
        
        // Z=0 plane (X-axis)
        const xPlaneBaseIndex = this.vertices.length / 3;
        
        // bottom-left corner
        this.vertices.push(0, 0, 0);
        this.normals.push(0, 0, -1);
        this.texCoords.push(0, 1);
        
        // yop-left corner
        this.vertices.push(0, this.height, 0);
        this.normals.push(0, 0, -1);
        this.texCoords.push(0, 0);
        
        // bottom-right corner
        this.vertices.push(this.radius, 0, 0);
        this.normals.push(0, 0, -1);
        this.texCoords.push(1, 1);
        
        // top-right corner
        this.vertices.push(this.radius, this.height, 0);
        this.normals.push(0, 0, -1);
        this.texCoords.push(1, 0);
        
        this.indices.push(
            xPlaneBaseIndex, xPlaneBaseIndex + 1, xPlaneBaseIndex + 2,
            xPlaneBaseIndex + 1, xPlaneBaseIndex + 3, xPlaneBaseIndex + 2
        );

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
}