import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyCylinder } from './MyCylinder.js';
import { MyCube } from './MyCube.js';

/**
 * MyHeliHelice
 * @constructor
 * @param scene
 * @param vel
 */
export class MyHeliHelice extends CGFobject {
    constructor(scene, vel) {
        super(scene);

        this.helices    = new MyCube(scene);
        this.centerbase = new MyCylinder(scene, 15, 1.8, 1.6);
        this.centerstripe = new MyCylinder(scene, 15, 1.2, 2);

        this.heliceRotation = 0;
        this.rotationSpeed = vel;

        this.heliMaterial = new CGFappearance(this.scene);
        this.heliMaterial.setAmbient(0.6, 0.6, 0.6, 1.0);
        this.heliMaterial.setDiffuse(0.6, 0.6, 0.6, 0.7); 
        this.heliMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.heliMaterial.setShininess(100);

        this.baseMaterial = new CGFappearance(this.scene);
        this.baseMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.baseMaterial.setDiffuse(0.3, 0.3, 0.3, 0.7); 
        this.baseMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.baseMaterial.setShininess(100);
    }

    updateTextures(heli_texture, metal_texture) {
        this.heli_texture = heli_texture;
        this.metal_texture = metal_texture;
        
        if (heli_texture) {
            this.heliMaterial.setTexture(heli_texture);
        }
        
        if (metal_texture) {
            this.baseMaterial.setTexture(metal_texture);
        }
    }
    
    display(){
        const gl = this.scene.gl;

        // Rotate around Y axis
        this.scene.pushMatrix();
        this.scene.rotate(this.heliceRotation, 0, 1, 0);

        // Center
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, 0);
        this.centerbase.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.3, 0);
        this.centerstripe.display();
        this.scene.popMatrix();

        // Helices
        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.9, 0);
        this.scene.rotate(-Math.PI/4, 0, 1, 0);
        this.scene.scale(2.3, 0.3, 55);
        this.helices.display();
        this.scene.popMatrix();

        this.baseMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0.9, 0);
        this.scene.rotate(Math.PI/4, 0, 1, 0);
        this.scene.scale(2.3, 0.3, 55);
        this.helices.display();
        this.scene.popMatrix();
        
        this.scene.popMatrix();
    }
    
    update(t) {
        this.heliceRotation += this.rotationSpeed * Math.abs(t);
        
        // Keep the angle within 2π to avoid large values over time // AI based
        if (this.heliceRotation > Math.PI * 2) {
            this.heliceRotation -= Math.PI * 2;
        }
    }    
}

