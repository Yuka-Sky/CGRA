import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyHeliBody } from './MyHeliBody.js'; 
import { MyHeliHelice } from './MyHeliHelice.js';
import { MyHeliBackHelice } from './MyHeliBackHelice.js';
import { MyLineBucket } from './MyLineBucket.js';
import { MyDrop } from './MyDrop.js';	

/**
 * MyHeli
 * @constructor
 * @param scene
 * @param x - X Position
 * @param y - Y Position
 * @param z - Z Position
 * @param yy - Angle around the YY axis
 * @param vel - Initial speed of the helicopter
 */
export class MyHeli extends CGFobject {
    constructor(scene, x, y, z, yy, vel) {
        super(scene);

        this.body       = new MyHeliBody(scene);
        this.helice     = new MyHeliHelice(scene, 7);
        this.backHelice = new MyHeliBackHelice(scene, 8.5);
        this.bucket     = new MyLineBucket(scene);
        this.drop       = new MyDrop(scene);

        this.x  = x;
        this.y  = y;
        this.z  = z;
        this.yy = yy;
        this.velocity  = 0;
        this.maxVelocity = vel;
        this.direction = [Math.sin(this.yy), 0, Math.cos(this.yy)];
        this.cruisingAltitude = 100;
    
        // Initial position
        this.initialX = x;
        this.initialY = y;
        this.initialZ = z;
        this.initialYY = yy;

        // Inclination
        this.inclinAngle = 0;
        this.maxInclin   = Math.PI/12;
        this.inclinSpeed = 1;
        
        // State management
        this.states = {
            IDLE: 'idle',           // Helicopter on the helipad
            LIFTING: 'lifting',     // Lifting to cruising altitude with "P"
            FLYING: 'flying',       // Flying with or without water
            COLLECTED: 'collected', // Water collected and bucket is full 
            LANDING: 'landing',     // Descending to land
            RETURNING: 'returning'  // Automatically return if pressed "L" without water
        };
        this.currentState  = this.states.IDLE;
        this.heliceActive  = false;
        this.hasWater      = false;
        this.displayBucket = false;
    }

    updateTextures(heli_texture, glass_texture, metal_texture) {
        this.heli_texture = heli_texture;
        this.glass_texture = glass_texture;
        this.metal_texture = metal_texture;
        
        if (this.body) {
            this.body.updateTextures(heli_texture, glass_texture, metal_texture);
        }
        if (this.helice) {
            this.helice.updateTextures(heli_texture, metal_texture);
        }
        if (this.backHelice) {
            this.backHelice.updateTextures(heli_texture, metal_texture);
        }
    }

    display(){
        const gl = this.scene.gl;

        this.scene.pushMatrix();

        this.scene.translate(this.x, this.y, this.z);  // Position
        this.scene.rotate(this.yy, 0, 1, 0);           // Orientation
        this.scene.rotate(this.inclinAngle, 1, 0, 0);  // Inclination
        this.scene.scale(0.2, 0.2, 0.2);
        this.body.display();

        this.scene.pushMatrix();
        this.scene.translate(0, 17.5, 0);
        this.helice.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 0, 1);
        this.scene.translate(-15, 0, -31);
        this.backHelice.display();
        this.scene.popMatrix();

        if (this.displayBucket) {
            this.scene.pushMatrix();
            this.scene.translate(0, -35, 0);
            this.bucket.display();
            this.scene.popMatrix();
        }

        this.scene.popMatrix();
        
        this.drop.display();
        
        this.scene.setDefaultAppearance();
    }
    
    // Method to update helicopter position and rotation based on time
    update(t) {
        // Update the helices only if they are active
        if (this.heliceActive) {
            this.helice.update(t);
            this.backHelice.update(t);
            this.updateInclination(t);
        }
        this.drop.update(t);
        
        switch (this.currentState) { // Based on state machine
            case this.states.IDLE:
                break;
                
            case this.states.LIFTING:
                const liftingSpeed = 30;
                this.y += this.direction[1] * liftingSpeed * t;
                
                if (this.y >= this.cruisingAltitude) {
                    this.y = this.cruisingAltitude;
                    this.displayBucket = true;
                    this.currentState = this.states.FLYING;
                    this.direction[1] = 0; // Stop vertical movement
                    this.velocity = 0;
                    console.log("Reached cruising altitude.");
                }
                break;

            case this.states.FLYING:
                this.x += this.direction[0] * this.velocity * t;
                this.y += this.direction[1] * this.velocity * t;
                this.z += this.direction[2] * this.velocity * t;
                break;
                
            case this.states.LANDING:
                const descendingSpeed = 30;
                this.y += this.direction[1] * descendingSpeed * t;

                // "L" on lake without water
                if (this.isOverLake() && !this.hasWater) {
                    if (this.y <= 5) {
                        this.y = 5;
                        this.direction[1] = 0;
                        this.velocity = 0;
                        this.fillWaterBucket();
                    }
                } 
                // Landing at helipad
                else if (Math.abs(this.x) < 5 && Math.abs(this.z + 140) < 5) {
                    if (this.y <= this.initialY) {
                        this.y = this.initialY;
                        this.x = 0;
                        this.z = -140;
                        this.currentState = this.states.IDLE;
                        this.heliceActive = false;
                        this.direction[1] = 0;
                        this.velocity = 0;
                        console.log("Landed at helipad.");
                    }
                } 
                break;

            case this.states.COLLECTED:
                this.hasWater = true;
                break;
                
            case this.states.RETURNING:
                const targetX = 0;
                const targetZ = -140;
                this.x += this.direction[0] * this.velocity * t;
                this.z += this.direction[2] * this.velocity * t;
                const dx = targetX - this.x;
                const dz = targetZ - this.z;
                const distance = Math.sqrt(dx*dx + dz*dz); // calculate distance to helipad
                
                // If we're close to the helipad, initiate landing
                if (distance < 5) {
                    this.currentState = this.states.LANDING;
                    this.displayBucket = false;
                    this.x = targetX;
                    this.z = targetZ;
                    this.direction[1] = -1;
                    this.velocity = 0;
                    console.log("Initiating landing sequence.");
                }
                break;
        }

    }
    
    accelerate(v) {
        if (this.currentState === this.states.FLYING) {
            if (v > 0) { // acceleration
                this.velocity += v;
                if (this.velocity > this.maxVelocity) {
                    this.velocity = this.maxVelocity;
                }
            } else if (v < 0) { //break
                if (this.velocity > 0) {
                    this.velocity = Math.max(0, this.velocity + v); // Stop the velocity at 0
                }
            }
        } else {
            console.log("Cannot accelerate.");
        }
    }

    turn(v) {
        if (this.currentState === this.states.FLYING) {
            this.yy += v;
            
            // Normalize angle to keep it in the range [0, 2π] - AI based
            this.yy = this.yy % (2 * Math.PI);
            if (this.yy < 0) this.yy += 2 * Math.PI;
            
            // Update direction
            this.direction[0] = Math.sin(this.yy);
            this.direction[2] = Math.cos(this.yy);
        } else {
            console.log("Cannot turn.");
        }
    }
    
    updateInclination(t) {
        let inclination = 0;
        const ratio = this.velocity / this.maxVelocity;

        // Store previous velocity to detect acceleration/deceleration
        if (this.prevVelocity === undefined) {
            this.prevVelocity = this.velocity;
        }
        const acceleration = this.velocity - this.prevVelocity;
        this.prevVelocity = this.velocity;
        
        if (this.currentState === this.states.FLYING || this.currentState === this.states.RETURNING) {
            if (this.velocity === 0) {
                inclination = 0;
            } else if (acceleration < 0) {
                inclination = -this.maxInclin * ratio;
            } else {
                inclination = this.maxInclin * ratio;
            }
        }
        
        // To make the movement more smooth - AI based
        if (this.inclinAngle !== inclination) {
            // Calculate step size for this frame
            const step = this.inclinSpeed * t;
            
            if (Math.abs(this.inclinAngle - inclination) < step) {
                this.inclinAngle = inclination;
            } else if (this.inclinAngle < inclination) {
                this.inclinAngle += step;
            } else {
                this.inclinAngle -= step;
            }
        }
    }

    reset() {
        this.x             = this.initialX;
        this.y             = this.initialY;
        this.z             = this.initialZ;
        this.yy            = this.initialYY;
        this.direction     = [Math.sin(this.yy), 0, Math.cos(this.yy)];
        this.currentState  = this.states.IDLE;
        this.heliceActive  = false;
        this.velocity      = 0;
        this.prevVelocity  = 0;
        this.inclinAngle   = 0;
        this.hasWater      = false;
        this.displayBucket = false;
        this.bucket.setWaterStatus(false);
        console.log(`Reset helicopter, now in IDLE state`);
    }
    
    updatePosition(ref, floorNumber) {
        const newHeight = (ref/9.6) * (floorNumber + 1);
        this.initialY = newHeight;
        
        if (this.currentState === this.states.IDLE) {
            this.y = newHeight;
        }
    }
    
    takeOff() {
        if (this.currentState === this.states.IDLE) {
            this.currentState = this.states.LIFTING;
            this.heliceActive = true;
            this.direction[1] = 1; // Ascend
            this.velocity = 0; // Reset velocity
            console.log("Helicopter taking off.");
        } else if (this.currentState === this.states.COLLECTED) {
            this.currentState = this.states.LIFTING;
            this.direction[1] = 0.5; // Ascend but not too fast due to water weight
            this.velocity = 0; // Reset velocity
            console.log("Taking off with water.");
        } else if (this.currentState === this.states.FLYING) {
            console.log("Already in flying state.");
        } else {
            console.log("Cannot take off in current state.");
        }
    }
    
    isOverLake() {
        // lake transformations made in MyScene
        const lakeCenterX = -110;
        const lakeCenterZ = 115;
        const lakeScale = 8.5;
        const lakeRotZAngle = -Math.PI / 4;
        
        // helicopter position to lake's local coordinates
        const relativeX = this.x - lakeCenterX;
        const relativeZ = this.z - lakeCenterZ;
        
        // inverse rotation (to undo the -PI/4 rotation)
        const cosZ = Math.cos(-lakeRotZAngle);
        const sinZ = Math.sin(-lakeRotZAngle);
        const rotatedX = relativeX * cosZ - relativeZ * sinZ;
        const rotatedZ = relativeX * sinZ + relativeZ * cosZ;
        
        // scale down to match lake's original dimensions
        const localX = rotatedX / lakeScale;
        const localZ = rotatedZ / lakeScale;
        
        const vertices = [
            [0, 10],     // 0
            [10, -0],    // 1
            [10, -5],    // 2
            [7.5, -10],  // 3
            [2.5, -10],  // 4
            [0, -5],     // 5
            [-2.5, -10], // 6
            [-7.5, -10], // 7
            [-10, -5],   // 8
            [-10, -0]    // 9
        ];
        
        const triangles = [
            [0, 1, 9],
            [1, 2, 9],
            [9, 2, 8],
            [2, 3, 4],
            [5, 2, 4],
            [8, 5, 6], 
            [8, 7, 6]
        ];
        
        // Check if point is inside a triangle using barycentric coordinates
        // (this next function was AI assisted)
        function pointInTriangle(px, pz, v0, v1, v2) {
            const x0 = v0[0], z0 = v0[1];
            const x1 = v1[0], z1 = v1[1];
            const x2 = v2[0], z2 = v2[1];
            
            const denom = (z1 - z2) * (x0 - x2) + (x2 - x1) * (z0 - z2);
            if (Math.abs(denom) < 1e-10) return false;
            
            const a = ((z1 - z2) * (px - x2) + (x2 - x1) * (pz - z2)) / denom;
            const b = ((z2 - z0) * (px - x2) + (x0 - x2) * (pz - z2)) / denom;
            const c = 1 - a - b;
            
            return a >= 0 && b >= 0 && c >= 0;
        }
        
        for (let triangle of triangles) {
            const v0 = vertices[triangle[0]];
            const v1 = vertices[triangle[1]];
            const v2 = vertices[triangle[2]];
            
            if (pointInTriangle(localX, localZ, v0, v1, v2)) {
                return true;
            }
        }
        
        return false;
    }

    isOverFire() {
        // fire transformations made in MyScene
        const fireOffset = 7;
        const fires = [
            { x: 130 + fireOffset, z: 120 + fireOffset, rotation: -Math.PI/2 }, // Fire 1 center
            { x: 100 + fireOffset, z: 80 + fireOffset, rotation: 0 },           // Fire 2 center
            { x: 160 + fireOffset, z: 50 + fireOffset, rotation: Math.PI/3 }    // Fire 3 center
        ];
        
        // total coverage area ~ 14x14 units
        const fireSize = 14;
        const fireRadius = fireSize / 2;
        
        for (let i = 0; i < fires.length; i++) {
            const fire = fires[i];

            // helicopter position relative to fire center
            let relativeX = this.x - fire.x;
            let relativeZ = this.z - fire.z;
            
            const distance = Math.sqrt(relativeX * relativeX + relativeZ * relativeZ);
            if (distance < 20) {
                console.log(`Close to Fire ${i+1}!`);
            }
            
            // inverse rotation to account for fire rotation
            if (fire.rotation !== 0) {
                let cosRot = Math.cos(-fire.rotation);
                let sinRot = Math.sin(-fire.rotation);
                let rotatedX = relativeX * cosRot - relativeZ * sinRot;
                let rotatedZ = relativeX * sinRot + relativeZ * cosRot;
                relativeX = rotatedX;
                relativeZ = rotatedZ;
            }
            
            // check if helicopter is within fire bounds (rectangular area)
            if (Math.abs(relativeX) <= fireRadius && Math.abs(relativeZ) <= fireRadius) {
                if (this.y <= 120) { // allow fire detection at cruising altitude
                    console.log(`Over Fire!`);
                    return true;
                }
            }
        }
        
        return false;
    }
    
    land() {
        if ((this.currentState === this.states.FLYING) && !this.hasWater) {
            if (this.isOverLake()) {
                this.currentState = this.states.LANDING;
                this.direction[1] = -0.5;
                this.velocity = 0;
            } else {
                this.returnToHelipad();
                console.log("Returning to helipad.");
            }
        } else if ((this.currentState === this.states.FLYING) && this.hasWater) {
            console.log("Cannot land - full bucket.");
        } else if (this.currentState === this.states.LANDING) {
            console.log("Already landing.");
        } else {
            console.log("Cannot perform this action in current state.");
        }
    }
    
    fillWaterBucket() {
        this.hasWater = true;
        this.bucket.setWaterStatus(true);
        this.currentState = this.states.COLLECTED;
        this.displayBucket = true;
        console.log("Water collected.");
    }
    
    releaseWater() {
        this.hasWater = false;
        this.bucket.setWaterStatus(false);
        this.drop.startFalling(this.x, this.y, this.z);
        this.currentState = this.states.FLYING;
        console.log("Water released.");
        return true;
        
    }
    
    returnToHelipad() {
        if (this.currentState === this.states.FLYING && !this.hasWater) {
            this.currentState = this.states.RETURNING;
            const targetX = 0;
            const targetZ = -140;
            const dx = targetX - this.x;
            const dz = targetZ - this.z;
            const distance = Math.sqrt(dx*dx + dz*dz);
            
            if (distance > 0.1) { // AI assisted
                // Normalize and set direction
                this.direction[0] = dx / distance;
                this.direction[2] = dz / distance;
                this.velocity = 40;
                
                // Calculate angle for rotation (yy)
                this.yy = Math.atan2(this.direction[0], this.direction[2]);
            } 
            else {
                this.currentState = this.states.LANDING;
                this.displayBucket = false;
                this.direction[1] = -1;
            }
        }
    }
}