import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyBucket } from './MyBucket.js';
import { MyCylinder } from './MyCylinder.js';
import { MySphere } from '../MySphere.js';

/**
 * MyLineBucket
 * @constructor
 * @param scene
 */
export class MyLineBucket extends CGFobject {
    constructor(scene) {
        super(scene);

        this.bucket         = new MyBucket(scene);
        this.suspentionline = new MyCylinder(scene, 15, 30, 0.25);
        this.sustain        = new MyCylinder(scene, 15, 20, 0.5);
        this.mainline       = new MyCylinder(scene, 15, 15, 0.15);
        this.knot           = new MySphere(scene, 15, 15, 0);
        
        this.hasWater = false;

        this.initMaterials();
    }
    
    setWaterStatus(hasWater) {
        this.hasWater = hasWater;
        this.bucket.setWaterStatus(hasWater);
    }
    
    initMaterials() {
        this.lineMaterial = new CGFappearance(this.scene);
        this.lineMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.lineMaterial.setDiffuse(0.6, 0.2, 0.2, 0.7); 
        this.lineMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.lineMaterial.setShininess(100);
    }

    display(){
        const gl = this.scene.gl;

        // Bucket
        this.scene.pushMatrix();
        this.scene.scale(0.5, 0.5, 0.5);
        this.bucket.display();
        this.scene.popMatrix();

        // 4 lines
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/9, 0, 0, 1);
        this.scene.translate(5.45, -0.1, -10);
        this.mainline.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/9, 0, 0, 1);
        this.scene.translate(-5.45, -0.1, -10);
        this.mainline.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/9, 0, 0, 1);
        this.scene.translate(5.45, -0.1, 10);
        this.mainline.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/9, 0, 0, 1);
        this.scene.translate(-5.45, -0.1, 10);
        this.mainline.display();
        this.scene.popMatrix();

        // Middle sustain
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 1, 0, 0);
        this.scene.translate(0, -10, 15.5);
        this.sustain.display();
        this.scene.popMatrix();

        // 2 closest lines
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/9, 1, 0, 0);
        this.scene.translate(0, 11, 14.7);
        this.suspentionline.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/9, 1, 0, 0);
        this.scene.translate(0, 11, -14.7);
        this.suspentionline.display();
        this.scene.popMatrix();

        // Knots
        this.scene.pushMatrix();
        this.scene.translate(0, 15.5, -10);
        this.scene.scale(0.5, 0.5, 0.5);
        this.knot.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, 15.5, 10);
        this.scene.scale(0.5, 0.5, 0.5);
        this.knot.display();
        this.scene.popMatrix();

        this.scene.setDefaultAppearance();

    }    
}