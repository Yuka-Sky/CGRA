import {CGFobject, CGFappearance} from '../../lib/CGF.js';
import { MyQuad } from "./MyQuad.js";
import { MyETriangle } from "./MyETriangle.js";
import { MyLTriangle } from './MyLTriangle.js';
import { MyParallelogram } from './MyParallelogram.js';

/**
 * MyHeliTail
 * @constructor
 * @param scene
 */
export class MyHeliTail extends CGFobject {
    constructor(scene) {
        super(scene);

        this.ltriangle = new MyLTriangle(scene);
        this.etriangle = new MyETriangle(scene);
        this.quad      = new MyQuad(scene);
        this.parallelg = new MyParallelogram(scene);

        this.initMaterials();
    }
    initMaterials() {
        this.heliMaterial = new CGFappearance(this.scene);
        this.heliMaterial.setAmbient(0.6, 0.6, 0.6, 1.0);
        this.heliMaterial.setDiffuse(0.6, 0.6, 0.6, 0.7); 
        this.heliMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.heliMaterial.setShininess(100);

        this.baseMaterial = new CGFappearance(this.scene);
        this.baseMaterial.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.baseMaterial.setDiffuse(0.3, 0.3, 0.3, 0.7); 
        this.baseMaterial.setSpecular(0.9, 0.9, 0.9, 1.0);
        this.baseMaterial.setShininess(100);
    }

    updateTextures(heli_texture) {
        this.heli_texture = heli_texture;
        
        if (heli_texture) {
            this.heliMaterial.setTexture(heli_texture);
        }
    }
    
    display(){
        const gl = this.scene.gl;

        // Top
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, 3.464);
        this.etriangle.display();
        this.scene.popMatrix();

        // Left
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.rotate(-Math.PI/6, 1, 0, 0);
        this.scene.translate(3.464, -1.5, 2.598);
        this.ltriangle.display();
        this.scene.popMatrix();

        // Right
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.rotate(Math.PI/6, 1, 0, 0);
        this.scene.translate(3.464, -1.5, -2.598);
        this.ltriangle.display();
        this.scene.popMatrix();

        // Back
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI, 0, 1, 0);
        this.scene.rotate(-0.589, 1, 0, 0);
        this.scene.scale(1, 1.202, 1);
        this.etriangle.display();
        this.scene.popMatrix();

        // Wing lateral
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.translate(2.77, 4.1, 0.6);
        this.parallelg.display();
        this.scene.popMatrix();
        
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI/2, 0, 1, 0);
        this.scene.translate(2.77, 4.1, -0.6);
        this.parallelg.display();
        this.scene.popMatrix();

        // Wing top
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 6.087, 5);
        this.scene.scale(1.2, 1.4, 1)
        this.quad.display();
        this.scene.popMatrix();
        // Wing bottom
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI, 0, 1, 0);
        this.scene.translate(0, 4.8, -2.77);
        this.scene.scale(1.2, 1.4, 1)
        this.quad.display();
        this.scene.popMatrix();
        // Wing back
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-2*Math.PI/3, 1, 0, 0);
        this.scene.translate(0, -6.4378, 3.378);
        this.scene.scale(1.2, 2.578, 1)
        this.quad.display();
        this.scene.popMatrix();
        // Wing front
        this.heliMaterial.apply();
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/3, 1, 0, 0);
        this.scene.translate(0, 5.7360, -2.1677);
        this.scene.scale(1.2, 2.578, 1)
        this.quad.display();
        this.scene.popMatrix();
    }    
}

