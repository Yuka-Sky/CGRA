import { CGFinterface, dat } from '../lib/CGF.js';

/**
* MyInterface
* @constructor
*/
export class MyInterface extends CGFinterface {
    constructor() {
        super();
    }

    init(application) {
        // call CGFinterface init
        super.init(application);

        // init GUI. For more information on the methods, check:
        // https://github.com/dataarts/dat.gui/blob/master/API.md
        this.gui = new dat.GUI();

        // Checkbox element in GUI
        this.gui.add(this.scene, 'displayAxis').name('Display Axis');
        
        // ----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // Environment ----------------------------------------------------------------------------------------------------------------------------------------------------
        var f1 = this.gui.addFolder('Environment');
        f1.add(this.scene, 'displayPanorama').name('Display Sky');
        f1.add(this.scene, 'displayPlane').name('Display Terrain'); 
        f1.add(this.scene, 'displayLake').name('Display Lake');
        this.textureOptions = {
            resolution: 'lowFields'
        };
        f1.add(this.textureOptions, 'resolution', ['lowFields', 'lowForest', 'mediumFields', 'mediumForest', 'highFields', 'highForest'])
            .name('Resolution')
            .onChange((value) => this.scene.updatePanoramaTexture(value));
        // ----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // Firefighters  --------------------------------------------------------------------------------------------------------------------------------------------------
        var f2 = this.gui.addFolder('Firefighters');
        const presetColors = {
            'White':  [1.0, 1.0, 1.0, 1.0],
            'Black':  [0.0, 0.0, 0.0, 1.0],
            'Red':    [1.0, 0.0, 0.0, 1.0],
            'Green':  [0.0, 1.0, 0.0, 1.0],
            'Blue':   [0.0, 0.0, 1.0, 1.0],
            'Cyan':   [0.0, 1.0, 1.0, 1.0],
            'Magenta':[1.0, 0.0, 1.0, 1.0],
            'Yellow': [1.0, 1.0, 0.0, 1.0],
        };  
        let params = {};
        const colorOptions = Object.keys(presetColors);
        params.color = colorOptions[0];

        f2.add(this.scene, 'displayBuilding').name('Display Building');
        f2.add(this.scene, 'buildingSize', 100, 250).name('Size').onChange(() => this.scene.updateBuilding());
        f2.add(this.scene, 'floorNumber', 0, 6).step(1).name('N° Floor').onChange(() => this.scene.updateBuilding());
        f2.add(this.scene, 'windowNumber', 0, 6).step(1).name('N° Window').onChange(() => this.scene.updateBuilding());
        f2.add(params, 'color', colorOptions).name('Wall Color').onChange((val) => {
            this.scene.updateBuildingColor(presetColors[val]);
        });

        // Dropdown for window textures
        f2.add(this.scene, 'selectedWindowTexture', this.scene.textureWindowIds).name('Window Texture').onChange(this.scene.updateBuildingTexture.bind(this.scene));
        f2.add(this.scene, 'selectedDoorTexture', this.scene.textureDoorsIds).name('Door Texture').onChange(this.scene.updateBuildingTexture.bind(this.scene));
        f2.add(this.scene, 'selectedWallTexture', this.scene.textureWallsIds).name('Wall Texture').onChange(this.scene.updateBuildingTexture.bind(this.scene));
        // ----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // Forest ---------------------------------------------------------------------------------------------------------------------------------------------------------
        var f3 = this.gui.addFolder('Vegetation');
        f3.add(this.scene, 'displayForest').name('Display Forest');
        f3.add(this.scene, 'selectedTrunk', Object.keys(this.scene.trunkTextures)).name('Trunk Style').onChange(() => this.scene.updateForests());
        f3.add(this.scene, 'selectedFoliage', Object.keys(this.scene.foliageTextures)).name('Foliage Style').onChange(() => this.scene.updateForests());
        // ----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // Helicopter  ----------------------------------------------------------------------------------------------------------------------------------------------------
        var f4 = this.gui.addFolder('Helicopter');
        f4.add(this.scene, 'displayHelicopter').name('Display Helicopter');
        f4.add(this.scene, 'speedFactor', 0.1, 3).name('Speed Factor');
        f4.add(this.scene, 'selectedHeliTexture', this.scene.textureHeliIds).name('Heli Texture').onChange(this.scene.updateHelicopterTexture.bind(this.scene));

        this.initKeys();

        return true;
    }

    initKeys() {
        // create reference from the scene to the GUI
        this.scene.gui = this;

        // disable the processKeyboard function
        this.processKeyboard = function () { };

        // create a named array to store which keys are being pressed
        this.activeKeys = {};
    }
    processKeyDown(event) {
        // called when a key is pressed down
        // mark it as active in the array
        this.activeKeys[event.code] = true;
    };

    processKeyUp(event) {
        // called when a key is released, mark it as inactive in the array
        this.activeKeys[event.code] = false;
    };

    isKeyPressed(keyCode) {
        // returns true if a key is marked as pressed, false otherwise
        return this.activeKeys[keyCode] || false;
    }

}