import {CGFobject, CGFappearance} from '../lib/CGF.js';

/**
 * MyLake
 */
export class MyLake extends CGFobject {
    constructor(scene, texture) {
        super(scene);
        this.texture = texture;
        
        this.initBuffers();
        this.initMaterial(); 
    }

    initBuffers() {
        this.vertices = [
            0, -10, 0,   // 0
            10, 0, 0,    // 1
            10, 5, 0,    // 2
            7.5, 10, 0,  // 3
            2.5, 10, 0,  // 4
            0, 5, 0,     // 5
            -2.5, 10, 0, // 6
            -7.5, 10, 0, // 7
            -10, 5, 0,   // 8
            -10, 0, 0    // 9
        ];
        this.indices = [
            0, 1, 9,
            1, 2, 9,
            9, 2, 8,
            2, 3, 4,
            5, 2, 4,
            8, 5, 6,
            8, 6, 7
        ];

        this.normals = [
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1
        ];

        this.texCoords = [
            0.5, 1,    // 0
            1, 0.5,    // 1
            1, 0.25,   // 2
            0.875, 0,  // 3
            0.625, 0,  // 4
            0.5, 0.25, // 5
            0.375, 0,  // 6
            0.125, 0,  // 7
            0, 0.25,   // 8
            0, 0.5     // 9
        ];

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();    
    }

    initMaterial() {
        this.lakeMaterial = new CGFappearance(this.scene);
        this.lakeMaterial.setAmbient(0.1, 0.5, 0.6, 1.0);
        this.lakeMaterial.setDiffuse(0.1, 0.5, 0.6, 1.0);
        this.lakeMaterial.setSpecular(0.1, 0.5, 0.6, 1.0);
        this.lakeMaterial.setShininess(15.0);
        this.lakeMaterial.setTexture(this.texture);
        this.lakeMaterial.setTextureWrap('REPEAT', 'REPEAT');
    }
    
    display() {
        this.scene.pushMatrix();
        this.lakeMaterial.apply();
        super.display();
        this.scene.popMatrix();
    }
}

