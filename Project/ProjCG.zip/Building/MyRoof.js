import {CGFobject} from '../../lib/CGF.js';
/**
 * MyRoof, based on MyQuad
 * @constructor
 * @param {MyScene} scene
 * @param {Array} coords
 */
export class MyRoof extends CGFobject {
	constructor(scene, coords) {
		super(scene);
		this.initBuffers();
		if (coords != undefined)
			this.updateTexCoords(coords);
	}
	
	initBuffers() {
		this.vertices = [
			0.5, 0.5, 0,	//0
			-0.5, 0.5, 0,	//1
			-0.5, -0.5, 0,	//2
			0.5, -0.5, 0	//3
		];

		this.indices = [
			0, 1, 2,
			2, 3, 0
		];

		this.normals = [
			0, 0, 1,
			0, 0, 1,
			0, 0, 1,
			0, 0, 1
		];
		
		this.texCoords = [
			1, 0,
			0, 0,
			0, 1,
			1, 1
		]
		this.primitiveType = this.scene.gl.TRIANGLES;
		this.initGLBuffers();
	}

	/**
	 * @method updateTexCoords
	 * Updates the list of texture coordinates of the quad
	 * @param {Array} coords - Array of texture coordinates
	 */
	updateTexCoords(coords) {
		this.texCoords = [...coords];
		this.updateTexCoordsGLBuffers();
	}
}

