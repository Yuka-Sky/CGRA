import {CGFappearance, CGFobject, CGFtexture} from '../../lib/CGF.js';
import { MyWall } from "./MyWall.js";
/**
 * MyFloor based on MyUnitCubeQuad
 * @constructor
 * @param scene
 */
export class MyFloor extends CGFobject {
    constructor(scene, front, right, back, left, color) {
        super(scene);

        this.color = color;
        this.front = this._createAppearance(front);
        this.right = this._createAppearance(right);
        this.back  = this._createAppearance(back);
        this.left  = this._createAppearance(left);

        this._applyColorToAppearances();

        this.retangle = {
            front: new MyWall(scene),
            right: new MyWall(scene),
            back: new MyWall(scene),
            left: new MyWall(scene),
        };
    }
    _createAppearance(texturePathOrObj) {
        const appearance = new CGFappearance(this.scene);
        const tex = texturePathOrObj instanceof CGFtexture 
            ? texturePathOrObj 
            : new CGFtexture(this.scene, texturePathOrObj);
        appearance.setTexture(tex);
        appearance.setTextureWrap('REPEAT', 'REPEAT');
        return appearance;
    }
    _applyColorToAppearances() {
        const [r, g, b, a] = this.color;
        this.front.setAmbient(r * 0.2, g * 0.2, b * 0.2, a);
        this.front.setDiffuse(r * 0.8, g * 0.8, b * 0.8, a);
        this.front.setSpecular(r * 0.5, g * 0.5, b * 0.5, a);
        
        this.right.setAmbient(r * 0.2, g * 0.2, b * 0.2, a);
        this.right.setDiffuse(r * 0.8, g * 0.8, b * 0.8, a);
        this.right.setSpecular(r * 0.5, g * 0.5, b * 0.5, a);
        
        this.back.setAmbient(r * 0.2, g * 0.2, b * 0.2, a);
        this.back.setDiffuse(r * 0.8, g * 0.8, b * 0.8, a);
        this.back.setSpecular(r * 0.5, g * 0.5, b * 0.5, a);
        
        this.left.setAmbient(r * 0.2, g * 0.2, b * 0.2, a);
        this.left.setDiffuse(r * 0.8, g * 0.8, b * 0.8, a);
        this.left.setSpecular(r * 0.5, g * 0.5, b * 0.5, a);
    }
    display(){
        const gl = this.scene.gl;
        const filter = this.scene.useNearestFiltering ? gl.NEAREST : gl.LINEAR;
    
        // Front Face (+Z)
        this.front.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, 0.5);
        this.retangle.front.display();
        this.scene.popMatrix();

    
        // Right Face (+X)
        this.right.apply();
        this.scene.pushMatrix();
        this.scene.translate(0.5, 0, 0);
        this.scene.rotate(Math.PI / 2, 0, 1, 0);
        this.retangle.right.display();
        this.scene.popMatrix();
            
        // Back Face (-Z)
        this.back.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, -0.5);
        this.scene.rotate(Math.PI, 0, 1, 0);
        this.retangle.back.display();
        this.scene.popMatrix();
    
        // Left Face (-X)
        this.left.apply();
        this.scene.pushMatrix();
        this.scene.translate(-0.5, 0, 0);
        this.scene.rotate(-Math.PI / 2, 0, 1, 0);
        this.retangle.left.display();
        this.scene.popMatrix();
    
    }    
}

