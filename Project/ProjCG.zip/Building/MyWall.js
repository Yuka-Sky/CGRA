import {CGFobject} from '../../lib/CGF.js';
/**
 * MyWall, based on MyQuad
 * @constructor
 * @param {MyScene} scene
 * @param {Array} coords
 */
export class MyWall extends CGFobject {
    constructor(scene, coords) {
        super(scene);
        this.initBuffers();
        if (coords != undefined)
            this.updateTexCoords(coords);
    }
    
    initBuffers() {
        this.vertices = [
            0.5, 0.25, 0,	//0
            -0.5, 0.25, 0,	//1
            -0.5, -0, 0,	//2
            0.5, -0, 0	    //3
        ];

        this.indices = [
            0, 1, 2,
            2, 3, 0
        ];

        this.normals = [
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1
        ];

        this.texCoords = [
            1, 0,
            0, 0,
            0, 1,
            1, 1
        ]
        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }

    updateTexCoords(scaleS, scaleT) {
        this.texCoords = [
            scaleS, 0,     // Top-right
            0, 0,          // Top-left
            0, scaleT,     // Bottom-left
            scaleS, scaleT // Bottom-right
        ];
        this.updateTexCoordsGLBuffers();
    }
}

