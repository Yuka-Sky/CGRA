import {CGFobject, CGFappearance, CGFshader } from '../../lib/CGF.js';
import { MyFloor } from "./MyFloor.js";
import { MyWindow } from "./MyWindow.js";
import { MyRoof } from "./MyRoof.js";
import { MyCylinder } from '../Helicopter/MyCylinder.js';
import { MySphere } from '../MySphere.js';

/**
 * MyFloor
 * @constructor
 * @param scene
 */
export class MyBuilding extends CGFobject {
    constructor(scene, build_size, build_floor, wind_number, wind_texture, door_texture, wall_texture, building_color) {
        super(scene);
        
        this.floor_numb = build_floor;
        this.wind_numb  = wind_number;
        this.building_color = building_color;

        // Texture References
        this.wind_texture = wind_texture;
        this.door_texture = door_texture;
        this.wall_texture = wall_texture;
        
        // Both these textures belong to MyBuilding constructor.
        // So when using them, we do: this.windowMaterial instead of this.scene.windowMaterial
        this.windowMaterial = new CGFappearance(scene);
        this.windowMaterial.setAmbient(0.2, 0.2, 0.2, 1);
        this.windowMaterial.setDiffuse(0.8, 0.8, 0.8, 1);
        this.windowMaterial.setSpecular(0.5, 0.5, 0.5, 1);
        this.windowMaterial.setShininess(10.0);
        this.windowMaterial.setTexture(wind_texture);
        this.windowMaterial.setTextureWrap('REPEAT', 'REPEAT');
        this.doorMaterial = new CGFappearance(scene);
        this.doorMaterial.setAmbient(0.2, 0.2, 0.2, 1);
        this.doorMaterial.setDiffuse(0.8, 0.8, 0.8, 1);
        this.doorMaterial.setSpecular(0.5, 0.5, 0.5, 1);
        this.doorMaterial.setShininess(10.0);
        this.doorMaterial.setTexture(door_texture);
        this.doorMaterial.setTextureWrap('REPEAT', 'REPEAT');

        this.central_ref      = 100 / 2.4;                                 // Largura do módulo central de base 1, equivalente à 100%
        this.mod_central      = build_size / 2.4;                          // Largura do módulo central de base 1, equivalente à 100%
        this.lateral_ref      = this.central_ref * 0.7;                    // Largura dos módulos laterais, compensa com a proporção de 70% do módulo central
        this.mod_lateral      = this.mod_central * 0.7;                    // Largura dos módulos laterais, compensa com a proporção de 70% do módulo central
        this.mob_height       = this.central_ref / 4;                      // Altura dos andares igual à todos
        this.mob_lat_position = (this.mod_central + this.mod_lateral) / 2; // Posição dos módulos laterais
        this.window_scale     = this.central_ref * 0.5;                    // Proporciona o tamanho da janela conforme a altura do andar
        this.dist_wall_window = this.central_ref / 40;                     // Espaçamento entre janela e parede em Y = 1/4 de 1/8
        this.w_range_center   = this.mod_central - 2*this.dist_wall_window;// Range limite de display das janelas no central
        this.w_range_lateral  = this.mod_lateral - 2*this.dist_wall_window;// Range limite de display das janelas na lateral
        this.avoid_collision  = (this.central_ref / 2) + 0.05;
        this.avoid_collision_lat = (this.lateral_ref / 2)  + 0.05;         // Espaço entre janela e parede em X central

        this.helipad_r = 100 * 0.15;
        this.helipad_height = 0.1;
 
        this.roof    = new MyRoof(scene);
        this.floor   = new MyFloor(scene, wall_texture, wall_texture, wall_texture, wall_texture, this.building_color);
        this.window  = new MyWindow(scene);
        this.door    = new MyWindow(scene);
        this.board   = new MyWindow(scene);
        this.helipad = new MyCylinder(scene, 32, this.helipad_height, this.helipad_r);

        this.disk    = new MyCylinder(scene, 10, 0.25, 1);
        this.light   = new MySphere(scene, 15, 5, false);
        
        this.initShaders();
    }
    
    initShaders() {
        /// Helipad
        this.helipadShader = new CGFshader(
            this.scene.gl, 
            "shaders/helipad.vert", 
            "shaders/helipad.frag"
        );
        
        this.helipadShader.setUniformsValues({
            timeFactor: 0.0,
            heliState: 0,
            uSamplerH: 0,   // H
            uSamplerUp: 1,  // UP
            uSamplerDown: 2 // DOWN
        });
        
        /// Lights
        this.lightShader = new CGFshader(
            this.scene.gl, 
            "shaders/light.vert", 
            "shaders/light.frag"
        );
        
        this.lightShader.setUniformsValues({
            timeFactor: 0.0,
            heliState: 0
        });
        
        this.startTime = performance.now();
    }
    
    updateShaders(t) {
        const elapsedTime = (t / 1000.0) % 3600.0;
        
        this.helipadShader.setUniformsValues({
            timeFactor: elapsedTime
        });
        
        this.lightShader.setUniformsValues({
            timeFactor: elapsedTime
        });
        
        if (this.scene.helicopter) {
            const heliState = this.scene.helicopter.currentState;
            let stateValue = 0;
            
            if (heliState === 'lifting') stateValue = 1;
            else if (heliState === 'landing') stateValue = 2;
            else if (heliState === 'returning') stateValue = 3;
            
            this.helipadShader.setUniformsValues({ heliState: stateValue });
            this.lightShader.setUniformsValues({ heliState: stateValue });
        }
    }
    
    updateTextures(wind_texture, door_texture, wall_texture, building_color) {
        this.wind_texture = wind_texture;
        this.door_texture = door_texture;
        this.wall_texture = wall_texture;
        
        if (building_color) {
            this.building_color = building_color;
        }

        this.windowMaterial.setTexture(wind_texture);
        this.doorMaterial.setTexture(door_texture);
        
        this.floor = new MyFloor(
            this.scene, 
            wall_texture, 
            wall_texture, 
            wall_texture, 
            wall_texture,
            this.building_color
        );
    }
    
    display(){
        const gl = this.scene.gl;

        // Central R/C
        this.scene.pushMatrix();
        this.scene.translate(0, 0, 0);
        this.scene.scale(this.mod_central, this.central_ref, this.central_ref);
        this.floor.display();
        this.scene.popMatrix();
        
        // Board 0.5 x 0.1
        this.scene.board.apply();
        this.scene.pushMatrix();
        this.scene.translate(0,  this.window_scale*0.4 , this.avoid_collision);
        this.scene.rotate(Math.PI / 15, 1, 0, 0);
        this.scene.scale(this.window_scale * 2.5, this.window_scale/4, this.window_scale);
        this.board.display();
        this.scene.popMatrix();
        this.scene.setDefaultAppearance();

        // Entrance 0.4 x 0.4
        this.doorMaterial.apply();
        this.scene.pushMatrix();
        this.scene.translate(0, 0, this.avoid_collision);
        this.scene.scale(this.window_scale * 2, this.window_scale, this.window_scale);
        this.door.display();
        this.scene.popMatrix();
        this.scene.setDefaultAppearance(); 

        for (let i = 1; i <= this.scene.floorNumber; i++) {
            let floors = i * this.mob_height;

            // Central Floors
            this.scene.pushMatrix();
            this.scene.translate(0, floors, 0);
            this.scene.scale(this.mod_central, this.central_ref, this.central_ref);
            this.floor.display();
            this.scene.popMatrix();

            // Left Floors
            this.scene.pushMatrix();
            this.scene.translate(-this.mob_lat_position, floors-this.mob_height, 0);
            this.scene.scale(this.mod_lateral, this.central_ref, this.lateral_ref);
            this.floor.display();
            this.scene.popMatrix();

            // Right Floors
            this.scene.pushMatrix();
            this.scene.translate(this.mob_lat_position, floors-this.mob_height, 0);
            this.scene.scale(this.mod_lateral, this.central_ref, this.lateral_ref);
            this.floor.display();
            this.scene.popMatrix();


            /// Windows
            let wind_space_centerMod = (this.w_range_center / (this.wind_numb + 1));
            let initial_x_central = -this.mod_central / 2 + this.dist_wall_window; // Começa na borda esquerda

            let wind_space_lateralMod = (this.w_range_lateral / (this.wind_numb + 1));
            let initial_x_lateral = -this.mod_lateral / 2 + this.dist_wall_window; //+ 0.1*this.window_scale; // Começa na borda esquerda 

            for (let j = 1; j <= this.wind_numb; j++) {
                let x_central = initial_x_central + j * wind_space_centerMod;
                let x_lateral = initial_x_lateral + j * wind_space_lateralMod;
    
                // Central windows
                this.windowMaterial.apply();
                this.scene.pushMatrix();
                this.scene.translate(x_central, this.dist_wall_window + floors, this.avoid_collision);
                this.scene.scale(this.window_scale, this.window_scale, this.window_scale);
                this.window.display();
                this.scene.popMatrix();
                this.scene.setDefaultAppearance();

                // Right Windows
                this.windowMaterial.apply();
                this.scene.pushMatrix();
                this.scene.translate(this.mob_lat_position + x_lateral, this.dist_wall_window + floors - this.mob_height, this.avoid_collision_lat);
                this.scene.scale(this.window_scale, this.window_scale, this.window_scale);
                this.window.display();
                this.scene.popMatrix();
                this.scene.setDefaultAppearance();

                // Left Windows
                this.windowMaterial.apply();
                this.scene.pushMatrix();
                this.scene.translate(-(this.mob_lat_position + x_lateral), this.dist_wall_window + floors - this.mob_height, this.avoid_collision_lat);
                this.scene.scale(this.window_scale, this.window_scale, this.window_scale);
                this.window.display();
                this.scene.popMatrix();
                this.scene.setDefaultAppearance();
            }
        }

        this.scene.setDefaultAppearance(); 

        let roof_height = this.scene.floorNumber * this.central_ref / 4;

        // Central Roof
        this.scene.concrete.apply();
        this.scene.pushMatrix();
        this.scene.rotate(-Math.PI / 2, 1, 0, 0);
        this.scene.translate(0, 0, roof_height + this.mob_height); // X, Z, Y
        this.scene.scale(this.mod_central, this.central_ref, this.central_ref);
        this.roof.display();
        this.scene.popMatrix();

        if (this.scene.floorNumber != 0){
            this.scene.concrete.apply();
            // Left Roof
            this.scene.pushMatrix();
            this.scene.rotate(-Math.PI / 2, 1, 0, 0);
            this.scene.translate(-this.mob_lat_position, 0, roof_height); // X, Z, Y
            this.scene.scale(this.mod_lateral, this.lateral_ref, this.lateral_ref);
            this.roof.display();
            this.scene.popMatrix();

            // Right Roof
            this.scene.pushMatrix();
            this.scene.rotate(-Math.PI / 2, 1, 0, 0);
            this.scene.translate(this.mob_lat_position, 0, roof_height); // X, Z, Y
            this.scene.scale(this.mod_lateral, this.lateral_ref, this.lateral_ref);
            this.roof.display();
            this.scene.popMatrix();
        }

        /// Disks for lights
        // 1:
        this.scene.concrete.apply();
        this.scene.pushMatrix();
        this.scene.translate(-this.helipad_r + 3, roof_height + this.mob_height, -this.helipad_r + 3);
        this.disk.display();
        this.scene.popMatrix();
        // 2:
        this.scene.concrete.apply();
        this.scene.pushMatrix();
        this.scene.translate(this.helipad_r - 3, roof_height + this.mob_height, -this.helipad_r + 3);
        this.disk.display();
        this.scene.popMatrix();
        // 3:
        this.scene.concrete.apply();
        this.scene.pushMatrix();
        this.scene.translate(-this.helipad_r + 3, roof_height + this.mob_height, this.helipad_r - 3);
        this.disk.display();
        this.scene.popMatrix();
        // 4:
        this.scene.concrete.apply();
        this.scene.pushMatrix();
        this.scene.translate(this.helipad_r - 3, roof_height + this.mob_height, this.helipad_r - 3);
        this.disk.display();
        this.scene.popMatrix();
        
        /// Lights
        // 1
        this.scene.setActiveShader(this.lightShader);
        this.scene.pushMatrix();
        this.scene.translate(-this.helipad_r + 3, roof_height + this.mob_height, -this.helipad_r + 3);
        this.scene.scale(0.65,0.65,0.65);
        this.light.display();
        this.scene.popMatrix();
        // 2
        this.scene.pushMatrix();
        this.scene.translate(this.helipad_r - 3, roof_height + this.mob_height, -this.helipad_r + 3);
        this.scene.scale(0.65,0.65,0.65);
        this.light.display();
        this.scene.popMatrix();
        // 3
        this.scene.pushMatrix();
        this.scene.translate(-this.helipad_r + 3, roof_height + this.mob_height, this.helipad_r - 3);
        this.scene.scale(0.65,0.65,0.65);
        this.light.display();
        this.scene.popMatrix();
        // 4
        this.scene.pushMatrix();
        this.scene.translate(this.helipad_r - 3, roof_height + this.mob_height, this.helipad_r - 3);
        this.scene.scale(0.65,0.65,0.65);
        this.light.display();
        this.scene.popMatrix();

        /// Helipad
        this.scene.setActiveShader(this.helipadShader);
        this.scene.helipadTexture.bind(0);
        this.scene.helipadUpTexture.bind(1);
        this.scene.helipadDownTexture.bind(2);
        this.scene.pushMatrix();
        this.scene.translate(0, roof_height + this.mob_height, 0);
        this.helipad.display();
        this.scene.popMatrix();
    }    
}

