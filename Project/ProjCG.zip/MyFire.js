import {CGFobject, CGFappearance, CGFshader} from '../lib/CGF.js';
import { MyFlame } from './MyFlame.js';

/**
 * MyFire
 */
export class MyFire extends CGFobject {
    constructor(scene, width, height, lines, columns, texture) {
        super(scene);
        
        this.width = width;
        this.height = height;
        
        this.lines = lines;
        this.columns = columns;
        this.texture = texture;
        
        this.initShader();
        this.initMaterial();        
        
        this.fire = []; // n*m matrix
        for (let i = 0; i < this.lines; i++){
            let temp = [];
            for (let j = 0; j < this.columns; j++){
                        
                // Width
                // if width < 5 : [5,10]
                // else [width-5,width+5]
                let tempWidth = this.width < 5 ? Math.floor(Math.random() * (10 - (5)) + (5)) : Math.floor(Math.random() * (this.width+5 - (this.width-5)) + (this.width-5));

                // Height
                // if height < 5 : [3,17]
                // else [height-7,height+7]
                let tempHeight = this.height < 5 ? Math.floor(Math.random() * (14 - (3)) + (3)) : Math.floor(Math.random() * (this.height+14 - (this.height-7)) + (this.height-7));

                temp.push({
                    flame: new MyFlame(scene, tempWidth, tempHeight, this.flameShader, this.flameMaterial),
                    offsetX: Math.floor(Math.random() * (2 + 2) - 2),
                    offsetZ: Math.floor(Math.random() * (2 + 2) - 2),
                    rotation: Math.random() * Math.PI * 2
                });            
            }
            this.fire.push(temp);
        }
    }    
    
    initShader() {
        this.flameShader = new CGFshader(this.scene.gl, "shaders/flame.vert", "shaders/flame.frag");
        this.flameShader.setUniformsValues({
            timeFactor: 0,
            flameIntensity: 0.7
        });
        
        this.startTime = performance.now();
    }
    
    initMaterial() {
        this.flameMaterial = new CGFappearance(this.scene);
        this.flameMaterial.setAmbient(1.0, 0.6, 0.2, 1.0);
        this.flameMaterial.setDiffuse(1.0, 0.6, 0.2, 1.0);
        this.flameMaterial.setSpecular(1.0, 0.8, 0.4, 1.0);
        this.flameMaterial.setShininess(10.0);
        this.flameMaterial.setEmission(1.0, 0.3, 0.1, 0); 
        this.flameMaterial.setTexture(this.texture);
        this.flameMaterial.setTextureWrap('REPEAT', 'REPEAT');
    }    
    
    display() {
        const currentTime = performance.now();
        const elapsedTime = (currentTime - this.startTime) / 350.0;
        
        this.flameShader.setUniformsValues({
            timeFactor: elapsedTime
        });
        
        
        for (let i = 0; i < this.lines; i++)
            for (let j = 0; j < this.columns; j++){
                this.scene.pushMatrix();
                this.scene.translate(i * 5.5 + this.fire[i][j].offsetX, 0, j * 5.5 + this.fire[i][j].offsetZ);
                this.scene.rotate(this.fire[i][j].rotation, 0, 1, 0); 
                this.fire[i][j].flame.display();
                this.scene.popMatrix();
        }
        
    }
      
    update(t) {
        const elapsedTime = (t - this.startTime) / 350.0;
        this.flameShader.setUniformsValues({
            timeFactor: elapsedTime
        });
    }
}