import { CGFobject } from '../lib/CGF.js';
import { MyTree } from './MyTree.js';

export class MyForest extends CGFobject {
    constructor(scene, lines, columns, quantityPerc = 5, trunkTexture = null, foliageTexture = null) {
        super(scene);
        this.lines = lines;
        this.columns = columns;
        this.quantityPerc = quantityPerc;

        this.forest = []; // (AxB) matrix
        for (let i = 0; i < this.lines; i++){
            let temp = [];
            // Creation of a tree:
            for (let j = 0; j < this.columns; j++){
                        
                // TILT ANGLE
                // Goes from -15 to 15
                let tiltAngle = Math.floor(Math.random() * (15 - (-15)) + (-15));
                // TILT AXIS
                // 50% chance of being either 'X' or 'Z'
                let tiltAxis = (Math.floor(Math.random() * 10) > 5) ? 'X' : 'Z';
                // TRUNK RADIUS
                // Goes from 0.7 to 1.5
                let trunkRadius = (Math.random() * (1.5 - 0.7) + 0.7);
                // HEIGHT
                // radius * 13
                let treeHeight = trunkRadius * 13;
                // COLOR
                // R: goes from 0.0 to 0.6
                // G: R + 0.4
                // B: R - random from [-0.1 ; 0.1]
                let R = Math.random() * 0.6;
                let B = (Math.random() * (0.1 + 0.1) -0.1);
                let foliageColor = [R, R + 0.4, R-B];

                let probability1 = Math.random(); // probability of having a tree
                let probability2 = Math.random(); // probability of filling with empty space

                if (probability1 <= this.quantityPerc){
                    temp.push({
                    tree: new MyTree(scene, tiltAngle, tiltAxis, trunkRadius, treeHeight, foliageColor, trunkTexture, foliageTexture),
                    offsetX: Math.floor(Math.random() * (2 + 2) - 2),
                    offsetZ: Math.floor(Math.random() * (2 + 2) - 2)
                    });   
                } else if (probability2 <= this.quantityPerc) {
                    temp.push(null); // null for positions without trees
                }
                        
            }
            this.forest.push(temp);
        }
    }

    display() {
        for (let i = 0; i < this.lines; i++)
            for (let j = 0; j < this.columns; j++){
                if (this.forest[i][j]){
                    this.scene.pushMatrix();
                    this.scene.translate(i * 6.5 + this.forest[i][j].offsetX, 0, j * 6.5 + this.forest[i][j].offsetZ);
                    this.forest[i][j].tree.display();
                    this.scene.popMatrix();
                }
                
        }
    }
}

