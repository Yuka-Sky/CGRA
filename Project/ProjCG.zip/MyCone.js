import { CGFobject } from '../lib/CGF.js';

export class MyCone extends CGFobject {
    constructor(scene, slices, height, radius) {
        super(scene);
        this.slices = slices;
        this.height = height;
        this.radius = radius;
        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];

        const angle = (2 * Math.PI) / this.slices;

        // Base vertices
        for (let i = 0; i < this.slices; i++) {
            let x = Math.cos(i * angle) * this.radius;
            let z = Math.sin(i * angle) * this.radius;
            this.vertices.push(x, 0, z);
            this.normals.push(0, -1, 0);
            this.texCoords.push((x / (2 * this.radius)) + 0.5, (z / (2 * this.radius)) + 0.5);
        }

        // Base center
        this.vertices.push(0, 0, 0);
        this.normals.push(0, -1, 0);
        this.texCoords.push(0.5, 0.5);
        const baseCenterIndex = this.vertices.length / 3 - 1;

        // Apex
        this.vertices.push(0, this.height, 0);
        this.normals.push(0, 1, 0);
        this.texCoords.push(0.5, 0);
        const apexIndex = this.vertices.length / 3 - 1;

        // Base indices
        for (let i = 0; i < this.slices; i++) {
            const next = (i + 1) % this.slices;
            this.indices.push(baseCenterIndex, i, next);
        }

        // Side faces
        for (let i = 0; i < this.slices; i++) {
            const next = (i + 1) % this.slices;

            let x0 = Math.cos(i * angle) * this.radius;
            let z0 = Math.sin(i * angle) * this.radius;
            let x1 = Math.cos(next * angle) * this.radius;
            let z1 = Math.sin(next * angle) * this.radius;

            const idx0 = this.vertices.length / 3;
            this.vertices.push(x0, 0, z0);
            const idx1 = this.vertices.length / 3;
            this.vertices.push(x1, 0, z1);
            const idxApex = this.vertices.length / 3;
            this.vertices.push(0, this.height, 0);

            let normal = [
                (x0 + x1) / 2,
                this.radius / this.height,
                (z0 + z1) / 2
            ];
            let length = Math.hypot(...normal);
            normal = normal.map(n => n / length);

            for (let j = 0; j < 3; j++) {
                this.normals.push(...normal);
            }

            this.texCoords.push(i / this.slices, 1);   // bottom left
            this.texCoords.push((i+1) / this.slices, 1); // bottom right
            this.texCoords.push((i+0.5) / this.slices, 0); // top middle

            this.indices.push(idx0, idxApex, idx1);
        }

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
}
