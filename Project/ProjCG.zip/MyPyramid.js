import { CGFobject } from '../lib/CGF.js';

export class MyPyramid extends CGFobject {
    constructor(scene, baseSize, height) {
        super(scene);
        this.baseSize = baseSize;
        this.height = height;
        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [
            // Base (square)
            -this.baseSize, 0, -this.baseSize,   // 0 - Bottom left
             this.baseSize, 0, -this.baseSize,   // 1 - Bottom right
             this.baseSize, 0, this.baseSize,    // 2 - Top right
            -this.baseSize, 0, this.baseSize,    // 3 - Top left
            // Tip
            0, this.height, 0   
        ];

        this.indices = [
            0, 1, 2,
            0, 2, 3,
            4, 1, 0,
            4, 2, 1,
            4, 3, 2,
            4, 0, 
        ];

        this.normals = [
            0, -1, 0, 
            0, -1, 0,
            0, -1, 0,
            0, -1, 0,
            0, 1, 0  
        ];

        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
}
