import {CGFobject} from '../lib/CGF.js';

/**
 * MyFlame
 */
export class MyFlame extends CGFobject {
    constructor(scene, width, height, sharedShader, sharedMaterial) {
        super(scene);
        this.width = width;
        this.height = height;
        
        this.shader = sharedShader;
        this.flameMaterial = sharedMaterial;
        
        this.randomFactor = Math.random() * Math.PI * 2;
        this.flameIntensity = 0.4 + Math.random() * 0.6;
        
        this.subdivisions = 5; // 5 levels for the flame
        
        this.initBuffers();
    }
    
    initBuffers() {
        this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];
        
        // XY plane
        this.createSubdividedFlame(true);
        
        // YZ plane
        this.createSubdividedFlame(false);
        
        this.originalVertices = [...this.vertices];
        
        this.animatedVertexIndices = [];
        for (let i = 0; i < this.vertices.length / 3; i++) {
            // Only animate vertices that are not at the base (y > 0)
            if (this.vertices[i * 3 + 1] > 0.1) {
                this.animatedVertexIndices.push(i);
            }
        }
        
        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }
    
    createSubdividedFlame(isXYPlane) {
        const baseWidth = this.width;
        const baseHeight = this.height;
        
        const levelHeight = baseHeight / this.subdivisions;
        
        for (let level = 0; level < this.subdivisions; level++) {
            // current level's y-position and width
            const y = level * levelHeight;
            const nextY = (level + 1) * levelHeight;
            
            const currentWidth = baseWidth * (1 - level / this.subdivisions);
            const nextWidth = baseWidth * (1 - (level + 1) / this.subdivisions); // narrower as the level increases
            
            // front and back facing triangles for this level
            this.createLevelTriangles(
                isXYPlane, 
                y, nextY, 
                currentWidth, nextWidth,
                level, this.subdivisions
            );
        }
    }
      
    createLevelTriangles(isXYPlane, y, nextY, currentWidth, nextWidth, level, totalLevels) {
        const vertexCount = this.vertices.length / 3;
        const thickness = 0.1;
        
        if (isXYPlane) {
            // XY plane front face
            this.addVertex(-currentWidth / 2, y, thickness);   // bottom left
            this.addVertex(currentWidth / 2, y, thickness);    // bottom right
            this.addVertex(-nextWidth / 2, nextY, thickness);  // top left
            this.addVertex(currentWidth / 2, y, thickness);    // bottom right
            this.addVertex(nextWidth / 2, nextY, thickness);   // top right
            this.addVertex(-nextWidth / 2, nextY, thickness);  // top left
            
            for (let i = 0; i < 6; i++) {
                this.normals.push(0, 0, 1);
            }
            
            // XY plane back face
            this.addVertex(currentWidth / 2, y, -thickness);   // bottom right
            this.addVertex(-currentWidth / 2, y, -thickness);  // bottom left
            this.addVertex(nextWidth / 2, nextY, -thickness);  // top right
            this.addVertex(-currentWidth / 2, y, -thickness);  // bottom left
            this.addVertex(-nextWidth / 2, nextY, -thickness); // top left
            this.addVertex(nextWidth / 2, nextY, -thickness);  // top right
            
            for (let i = 0; i < 6; i++) {
                this.normals.push(0, 0, -1);
            }
        } 
        
        else {
            // YZ plane front face
            this.addVertex(thickness, y, -currentWidth / 2);   // bottom left
            this.addVertex(thickness, y, currentWidth / 2);    // bottom right
            this.addVertex(thickness, nextY, -nextWidth / 2);  // top left
            this.addVertex(thickness, y, currentWidth / 2);    // bottom right
            this.addVertex(thickness, nextY, nextWidth / 2);   // top right
            this.addVertex(thickness, nextY, -nextWidth / 2);  // top left
            
            for (let i = 0; i < 6; i++) {
                this.normals.push(1, 0, 0);
            }
            
            // YZ plane back face
            this.addVertex(-thickness, y, currentWidth / 2);   // bottom right
            this.addVertex(-thickness, y, -currentWidth / 2);  // tottom left
            this.addVertex(-thickness, nextY, nextWidth / 2);  // top right
            this.addVertex(-thickness, y, -currentWidth / 2);  // bottom left
            this.addVertex(-thickness, nextY, -nextWidth / 2); // top left
            this.addVertex(-thickness, nextY, nextWidth / 2);  // top right
            
            for (let i = 0; i < 6; i++) {
                this.normals.push(-1, 0, 0);
            }
        }
        
        for (let i = 0; i < 2; i++) { // front and back
            const baseIndex = vertexCount + i * 6;
            // first triangle
            this.indices.push(baseIndex, baseIndex + 1, baseIndex + 2);
            // second triangle
            this.indices.push(baseIndex + 3, baseIndex + 4, baseIndex + 5);
        }
        
        const texYBottom = 1.0 - (level / totalLevels);
        const texYTop = 1.0 - ((level + 1) / totalLevels);
        
        // front - first triangle
        this.texCoords.push(0, texYBottom);  // bottom left
        this.texCoords.push(1, texYBottom);  // bottom right
        this.texCoords.push(0, texYTop);     // top left
        
        // front - second triangle
        this.texCoords.push(1, texYBottom);  // bottom right
        this.texCoords.push(1, texYTop);     // top right
        this.texCoords.push(0, texYTop);     // top left
        
        // back - first triangle
        this.texCoords.push(0, texYBottom);  // bottom left
        this.texCoords.push(1, texYBottom);  // bottom right
        this.texCoords.push(0, texYTop);     // top left
        
        // back - second triangle
        this.texCoords.push(1, texYBottom);  // bottom right
        this.texCoords.push(1, texYTop);     // top right
        this.texCoords.push(0, texYTop);     // top left
    }
    
    addVertex(x, y, z) {
        this.vertices.push(x, y, z);
    }
    
    display() {
        this.shader.setUniformsValues({
            randomFactor: this.randomFactor,
            flameIntensity: this.flameIntensity
        });
        
        this.flameMaterial.apply();
        super.display();
    }
}

