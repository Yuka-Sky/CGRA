import { CGFobject, CGFappearance } from '../lib/CGF.js';
import { MyCone } from './MyCone.js';
import { MyHexPyramid } from './MyHexPyramid.js';

export class MyTree extends CGFobject {
    constructor(scene, tiltAngle, tiltAxis, trunkRadius, treeHeight, foliageColor, trunkTexture, foliageTexture) {
        super(scene);
        
        this.tiltAngle = tiltAngle;
        this.tiltAxis = tiltAxis;
        this.trunkRadius = trunkRadius;
        this.treeHeight = treeHeight;
        this.foliageColor = foliageColor;

        // Trunk
        let trunkHeight = treeHeight * 0.55; // Trunk Height (to prevent the cone from looking weird - 55% of the tree's height)
        this.trunk = new MyCone(scene, 12, trunkHeight, trunkRadius);

        // Foliage
        let foliageHeight = treeHeight * 0.5; // Foliage extends past the trunk a little
        let baseRadius = trunkRadius * 2;
        let foliageLayersCount = Math.max(3, Math.round(treeHeight / 3));

        this.foliageLayers = [];
        let totalHeight = 0;
        for (let i = 0; i < foliageLayersCount; i++) {
            let layerHeight = (foliageHeight * 1.5) / foliageLayersCount; 
            let layerRadius = baseRadius * (1 - i * 0.12); // Layer tapering
            this.foliageLayers.push(new MyHexPyramid(scene, layerRadius, layerHeight));
            totalHeight += layerHeight * 0.8;
        }

        this.trunkMaterial = new CGFappearance(scene);
        this.trunkMaterial.setAmbient(0.4, 0.4, 0.4, 1);
        this.trunkMaterial.setDiffuse(0.8, 0.8, 0.8, 1);
        this.trunkMaterial.setSpecular(0.5, 0.5, 0.5, 1);
        this.trunkMaterial.setShininess(10.0);
        if (trunkTexture) this.trunkMaterial.setTexture(trunkTexture);

        this.foliageMaterial = new CGFappearance(scene);
        this.foliageMaterial.setAmbient(...foliageColor, 1);
        this.foliageMaterial.setDiffuse(...foliageColor, 1);
        this.foliageMaterial.setSpecular(0.5, 0.5, 0.5, 1);
        this.foliageMaterial.setShininess(10.0);
        if (foliageTexture) this.foliageMaterial.setTexture(foliageTexture);
    }

    display() {
        this.scene.pushMatrix();
        
        // Tilt tree
        if (this.tiltAxis === 'X') {
            this.scene.rotate(this.tiltAngle * Math.PI / 180, 1, 0, 0);
        } else {
            this.scene.rotate(this.tiltAngle * Math.PI / 180, 0, 0, 1);
        }

        // Draw trunk
        this.trunkMaterial.apply();
        this.scene.pushMatrix();
        this.trunk.display();
        this.scene.popMatrix();

        // Draw foliage
        this.foliageMaterial.apply();
        let heightOffset = this.treeHeight * 0.2; // Start foliage a bit higher on trunk
        for (let i = 0; i < this.foliageLayers.length; i++) {
            this.scene.pushMatrix();
            this.scene.translate(0, heightOffset, 0);
            this.foliageLayers[i].display();
            this.scene.popMatrix();
            heightOffset += this.foliageLayers[i].height * 0.7; // Layer stacking
        }

        this.scene.popMatrix();
    }
}
