import {CGFappearance, CGFscene, CGFcamera, CGFaxis, CGFtexture, CGFshader } from "../lib/CGF.js";
import { MyPlane } from "./MyPlane.js";
import { MyWindow } from "./Building/MyWindow.js";
import { MyRoof } from "./Building/MyRoof.js";
import { MyBuilding } from "./Building/MyBuilding.js";
import { MyPanorama } from './MyPanorama.js';
import { MyForest } from "./MyForest.js";
import { MyLake } from "./MyLake.js";
import { MyFire } from "./MyFire.js";
import { MyHeli } from "./Helicopter/MyHeli.js";

/**
 * MyScene
 * @constructor
 */
export class MyScene extends CGFscene {
  constructor() {
    super();
  }
  init(application) {
    super.init(application);
    this.initCameras();
    this.initLights();
    this.initMaterials();

    // Background color
    this.gl.clearColor(0, 0, 0, 1.0);

    this.gl.clearDepth(100.0);
    this.gl.enable(this.gl.DEPTH_TEST);
    this.gl.enable(this.gl.CULL_FACE);
    this.gl.depthFunc(this.gl.LEQUAL);
    this.enableTextures(true);

    this.setUpdatePeriod(50);
    
    this.buildingSize = 100.0; // Tamanho inicial
    this.floorNumber = 3; // valor inicial, por exemplo
    this.windowNumber = 2; // valor inicial, por exemplo

    // Initialize scene objects
    this.axis = new CGFaxis(this, 20, 1);
    this.plane = new MyPlane(this, 64, 0, 10, 0, 10);
    this.window = new MyWindow(this);
    this.roof = new MyRoof(this);

    // Display control
    this.displayAxis = true;
    this.displayPlane = true;
    this.displayForest = true;
    this.displayLake = true;
    this.displayHelicopter = true;
    this.displayBuilding = true;
    this.displayPanorama = true;
    this.displayFire1 = true;
    this.displayFire2 = true;
    this.displayFire3 = true;

    // Forest
    this.selectedTrunk = "Default";
    this.selectedFoliage = "Default";
    this.updateForests();

    // Lake
    this.waterTex = new CGFtexture(this, "textures/waterTex.jpg");
    this.lake = new MyLake(this, this.waterTex);    
    
    // Helicopter
    this.selectedHeliTexture = 0;
    var heliHeight = (this.floorNumber + 1)*(100/9.6);
    this.helicopter = new MyHeli(this, 0, heliHeight, -140, 0, 50);
    this.acceleration = 1;  // acceleration value
    this.rotationSpeed = 2; // rotation speed value
    this.delta_t = 0.01;  // Initialize delta_t
    this.speedFactor = 1;   // Speed factor for helicopter movement
    this.updateHelicopterTexture();

    // Building
    this.buildingColor = [1.0, 1.0, 1.0, 1.0];
    this.selectedWindowTexture = 0;
    this.selectedDoorTexture = 0;
    this.selectedWallTexture = 0;
    this.updateBuilding();

    // Sky-Sphere
    this.panorama = new MyPanorama(this, new CGFtexture(this, 'textures/backgroundlowFields.jpg'));    
    
    // Fire
    this.fire = new MyFire(this, 10, 13, 3, 3, new CGFtexture(this, "textures/firewithGradient.jpg"));
  }
  

  initMaterials() {
    // Plane
    this.grass = new CGFappearance(this);
    this.grass.setAmbient(0.1, 0.1, 0.1, 1);
    this.grass.setDiffuse(0.9, 0.9, 0.9, 1);
    this.grass.setSpecular(0.1, 0.1, 0.1, 1);
    this.grass.setShininess(10.0);
    this.grass.setTextureWrap('REPEAT', 'REPEAT');
    this.grass.setTexture(new CGFtexture(this, 'textures/grass.jpg'));

    // Forest
    this.trunkTextures = {
      "Default": new CGFtexture(this, "textures/trunk.jpg"),
      "Birch": new CGFtexture(this, "textures/birch_trunk.jpg"),
      "Pine": new CGFtexture(this, "textures/pine_trunk.jpg")
    };
    
    this.foliageTextures = {
        "Default": new CGFtexture(this, "textures/foliage.jpg"),
        "Dark Leaves": new CGFtexture(this, "textures/dark_foliage.jpg"),
        "Autumn": new CGFtexture(this, "textures/autumn_foliage.jpg")
    };

    // Helicopter
    this.heli_tex1 = new CGFtexture(this, 'textures/normalHeli.jpg');
    this.heli_tex2 = new CGFtexture(this, 'textures/minecraftHeli.jpg');
    this.heli_tex3 = new CGFtexture(this, 'textures/abandonedHeli.jpg');
    this.heliTextures = [this.heli_tex1, this.heli_tex2, this.heli_tex3];
    this.textureHeliIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};

    this.glass_tex1 = new CGFtexture(this, 'textures/normalGlass.jpg');
    this.glass_tex2 = new CGFtexture(this, 'textures/minecraftGlass.jpg');
    this.glass_tex3 = new CGFtexture(this, 'textures/abandonedGlass.jpg');
    this.glassTextures = [this.glass_tex1, this.glass_tex2, this.glass_tex3];
    this.textureGlassIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};

    this.metal_tex1 = new CGFtexture(this, 'textures/normalMetal.jpg');
    this.metal_tex2 = new CGFtexture(this, 'textures/minecraftMetal.jpg');
    this.metal_tex3 = new CGFtexture(this, 'textures/abandonedMetal.jpg');
    this.metalTextures = [this.metal_tex1, this.metal_tex2, this.metal_tex3];
    this.textureMetalIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};

    // Building
    this.concrete = new CGFappearance(this);
    this.concrete.setAmbient(0.2, 0.2, 0.2, 1);
    this.concrete.setDiffuse(0.8, 0.8, 0.8, 1);
    this.concrete.setSpecular(0.5, 0.5, 0.5, 1);
    this.concrete.setShininess(10.0);
    this.concrete.setTextureWrap('REPEAT', 'REPEAT');  
    this.concrete.setTexture(new CGFtexture(this, 'textures/concrete.jpg'));  

    this.red_concrete = new CGFappearance(this);
    this.red_concrete.setAmbient(0.2, 0.2, 0.2, 1);
    this.red_concrete.setDiffuse(0.8, 0.8, 0.8, 1);
    this.red_concrete.setSpecular(0.5, 0.5, 0.5, 1);
    this.red_concrete.setShininess(10.0);
    this.red_concrete.setTextureWrap('REPEAT', 'REPEAT');
    this.red_concrete.setTexture(new CGFtexture(this, 'textures/red_concrete.jpg'));

    this.redlight = new CGFappearance(this);
    this.redlight.setAmbient(0.8, 0.2, 0.2, 1);
    this.redlight.setDiffuse(0.8, 0.2, 0.2, 1);
    this.redlight.setSpecular(0.8, 0.2, 0.2, 1);
    this.redlight.setShininess(10.0);
    this.redlight.setEmission(0.8,0.2,0.2,1.0);
    this.redlight.setTextureWrap('REPEAT', 'REPEAT');

    this.pulsatingLight = new CGFappearance(this);
    this.pulsatingLight.setAmbient(0.8, 0.2, 0.2, 1);
    this.pulsatingLight.setDiffuse(0.8, 0.2, 0.2, 1);
    this.pulsatingLight.setSpecular(0.8, 0.2, 0.2, 1);
    this.pulsatingLight.setShininess(10.0);
    this.pulsatingLight.setTextureWrap('REPEAT', 'REPEAT');

    this.window = new CGFappearance(this);
    this.window.setAmbient(0.2, 0.2, 0.2, 1);
    this.window.setDiffuse(0.8, 0.8, 0.8, 1);
    this.window.setSpecular(0.5, 0.5, 0.5, 1);
    this.window.setShininess(10.0);
    this.window.loadTexture('textures/normalWindow.jpg');
    this.window.setTextureWrap('REPEAT', 'REPEAT');

    this.door = new CGFappearance(this);
    this.door.setAmbient(0.2, 0.2, 0.2, 1);
    this.door.setDiffuse(0.8, 0.8, 0.8, 1);
    this.door.setSpecular(0.5, 0.5, 0.5, 1);
    this.door.setShininess(10.0);
    this.door.loadTexture('textures/normalDoor.jpg');
    this.door.setTextureWrap('REPEAT', 'REPEAT');

    this.board = new CGFappearance(this);
    this.board.setAmbient(0.2, 0.2, 0.2, 1);
    this.board.setDiffuse(0.8, 0.8, 0.8, 1);
    this.board.setSpecular(0.5, 0.5, 0.5, 1);
    this.board.setShininess(10.0);
    this.board.loadTexture('textures/board_sign.jpg');
    this.board.setTextureWrap('REPEAT', 'REPEAT');    

    this.door_tex1 = new CGFappearance(this);
    this.door_tex1.setAmbient(0.2, 0.2, 0.2, 1);
    this.door_tex1.setDiffuse(0.8, 0.8, 0.8, 1);
    this.door_tex1.setSpecular(0.5, 0.5, 0.5, 1);
    this.door_tex1.setShininess(10.0);

    this.door_tex2 = new CGFappearance(this);
    this.door_tex2.setAmbient(0.2, 0.2, 0.2, 1);
    this.door_tex2.setDiffuse(0.8, 0.8, 0.8, 1);
    this.door_tex2.setSpecular(0.5, 0.5, 0.5, 1);
    this.door_tex2.setShininess(10.0);
    this.door_tex2.setTextureWrap('REPEAT', 'REPEAT');

    this.door_tex3 = new CGFappearance(this);
    this.door_tex3.setAmbient(0.2, 0.2, 0.2, 1);
    this.door_tex3.setDiffuse(0.8, 0.8, 0.8, 1);
    this.door_tex3.setSpecular(0.5, 0.5, 0.5, 1);
    this.door_tex3.setShininess(10.0);
    this.door_tex3.setTextureWrap('REPEAT', 'REPEAT');

    this.wind_tex1 = new CGFappearance(this);
    this.wind_tex1.setAmbient(0.2, 0.2, 0.2, 1);
    this.wind_tex1.setDiffuse(0.8, 0.8, 0.8, 1);
    this.wind_tex1.setSpecular(0.5, 0.5, 0.5, 1);
    this.wind_tex1.setShininess(10.0);

    this.wind_tex2 = new CGFappearance(this);
    this.wind_tex2.setAmbient(0.2, 0.2, 0.2, 1);
    this.wind_tex2.setDiffuse(0.8, 0.8, 0.8, 1);
    this.wind_tex2.setSpecular(0.5, 0.5, 0.5, 1);
    this.wind_tex2.setShininess(10.0);

    this.wind_tex3 = new CGFappearance(this);
    this.wind_tex3.setAmbient(0.2, 0.2, 0.2, 1);
    this.wind_tex3.setDiffuse(0.8, 0.8, 0.8, 1);
    this.wind_tex3.setSpecular(0.5, 0.5, 0.5, 1);
    this.wind_tex3.setShininess(10.0);

    this.helipad = new CGFappearance(this);
    this.helipad.setAmbient(0.2, 0.2, 0.2, 1);
    this.helipad.setDiffuse(0.8, 0.8, 0.8, 1);
    this.helipad.setSpecular(0.5, 0.5, 0.5, 1);
    this.helipad.setShininess(10.0);
    this.helipad.loadTexture('textures/helipad.jpg');
    this.helipad.setTextureWrap('REPEAT', 'REPEAT');
    this.helipadTexture = new CGFtexture(this, 'textures/helipad.jpg');

    this.helipadUp = new CGFappearance(this);
    this.helipadUp.setAmbient(0.2, 0.2, 0.2, 1);
    this.helipadUp.setDiffuse(0.8, 0.8, 0.8, 1);
    this.helipadUp.setSpecular(0.5, 0.5, 0.5, 1);
    this.helipadUp.setShininess(10.0);
    this.helipadUp.loadTexture('textures/up.jpg');
    this.helipadUp.setTextureWrap('REPEAT', 'REPEAT');
    this.helipadUpTexture = new CGFtexture(this, 'textures/up.jpg');

    this.helipadDown = new CGFappearance(this);
    this.helipadDown.setAmbient(0.2, 0.2, 0.2, 1);
    this.helipadDown.setDiffuse(0.8, 0.8, 0.8, 1);
    this.helipadDown.setSpecular(0.5, 0.5, 0.5, 1);
    this.helipadDown.setShininess(10.0);
    this.helipadDown.loadTexture('textures/down.jpg');
    this.helipadDown.setTextureWrap('REPEAT', 'REPEAT');
    this.helipadDownTexture = new CGFtexture(this, 'textures/down.jpg');

    this.wind_tex1 = new CGFtexture(this, 'textures/normalWindow.jpg');
    this.wind_tex2 = new CGFtexture(this, 'textures/minecraftWindow.jpg');
    this.wind_tex3 = new CGFtexture(this, 'textures/abandonedWindow.jpg');
    this.windowTextures = [this.wind_tex1, this.wind_tex2, this.wind_tex3];
    this.textureWindowIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};

    this.door_tex1 = new CGFtexture(this, 'textures/normalDoor.jpg');
    this.door_tex2 = new CGFtexture(this, 'textures/minecraftDoor.jpg');
    this.door_tex3 = new CGFtexture(this, 'textures/abandonedDoor.jpg');
    this.doorTextures = [this.door_tex1, this.door_tex2, this.door_tex3];
    this.textureDoorsIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};
 
    this.wall_tex1 = new CGFtexture(this, 'textures/red_bricks.jpg');
    this.wall_tex2 = new CGFtexture(this, 'textures/minecraftWall.jpg');
    this.wall_tex3 = new CGFtexture(this, 'textures/bricks.jpg');
    this.wallTextures = [this.wall_tex1, this.wall_tex2, this.wall_tex3];
    this.textureWallsIds = {'Normal': 0, 'Minecraft': 1, 'Abandoned': 2};

    // Extra
    this.debug = new CGFappearance(this);
    this.debug.setAmbient(0.2, 0.2, 0.2, 1);
    this.debug.setDiffuse(0.8, 0.8, 0.8, 1);
    this.debug.setSpecular(0.5, 0.5, 0.5, 1);
    this.debug.setShininess(10.0);
    this.debug.setTextureWrap('REPEAT', 'REPEAT');
    this.debug.setTexture(new CGFtexture(this, 'textures/debug.jpg'));

    this.caution_tape = new CGFappearance(this);
    this.caution_tape.setAmbient(0.2, 0.2, 0.2, 1);
    this.caution_tape.setDiffuse(0.8, 0.8, 0.8, 1);
    this.caution_tape.setSpecular(0.5, 0.5, 0.5, 1);
    this.caution_tape.setShininess(10.0);
    this.caution_tape.setTextureWrap('REPEAT', 'REPEAT');
    this.caution_tape.setTexture(new CGFtexture(this, 'textures/caution_tape.jpg'));
  }


  initLights() {
    this.lights[0].setPosition(200, 200, 200, 1);
    this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
    this.lights[0].enable();
    this.lights[0].update();
  }


  initCameras() {
    this.camera = new CGFcamera(
      1.0,
      0.1,
      1000,
      vec3.fromValues(200, 200, 200),
      vec3.fromValues(0, 0, 0)
    );
  }


  updateBuildingColor(color) {
    this.buildingColor = color;
    if (this.building) {
        this.building.updateTextures(
            this.windowTextures[this.selectedWindowTexture],
            this.doorTextures[this.selectedDoorTexture],
            this.wallTextures[this.selectedWallTexture],
            color
        );
    }
  }


  updateBuilding() {
    this.building = new MyBuilding(
      this, 
      this.buildingSize, 
      this.floorNumber, 
      this.windowNumber, 
      this.windowTextures[this.selectedWindowTexture],
      this.doorTextures[this.selectedDoorTexture],
      this.wallTextures[this.selectedWallTexture],
      this.buildingColor
    );
      // Update helicopter position when building height changes
    if (this.helicopter) {
      this.helicopter.updatePosition(100, this.floorNumber);
    }
  };


  updatePanoramaTexture(resolution) {
    let texturePath = `textures/background${resolution}.jpg`;
    this.panorama.texture = new CGFtexture(this, texturePath);
    this.panorama.material.setTexture(this.panorama.texture);
  }


  updateBuildingTexture() {
    if (this.building) {
        this.building.updateTextures(
            this.windowTextures[this.selectedWindowTexture],
            this.doorTextures[this.selectedDoorTexture],
            this.wallTextures[this.selectedWallTexture],
            this.buildingColor
        );
    }
    this.window.setTexture(this.windowTextures[this.selectedWindowTexture]);
    this.door.setTexture(this.doorTextures[this.selectedDoorTexture]);
  }


  updateHelicopterTexture() {
    if (this.helicopter) {
        this.helicopter.updateTextures(
            this.heliTextures[this.selectedHeliTexture],
            this.glassTextures[this.selectedHeliTexture],
            this.metalTextures[this.selectedHeliTexture]
        );
    }
  }


  updateForests() {
    this.forest = new MyForest(this, 30, 20, 0.65, this.trunkTextures[this.selectedTrunk], this.foliageTextures[this.selectedFoliage]);
  }


  update(t) {
    // Update fire animation if any fire is displayed
    if ((this.displayFire1 || this.displayFire2 || this.displayFire3) && this.fire) {
        this.fire.update(t);
    }
    
    // Update panorama cloud animation
    if (this.displayPanorama && this.panorama) {
        this.panorama.update(t);
    }
      
    // Update building shaders for helipad and light animations
    if (this.building) {
        this.building.updateShaders(t);
    }
    
    // AI based-------------------------------------------------------------
    // Static variable to keep track of the last update time
    if (!this.lastT) {
      this.lastT = t;
      return;
    }
    
    // Calculate actual elapsed time since last frame
    const elapsed = t - this.lastT;
    this.lastT = t;
    
    // Convert to seconds and ensure it's a reasonable value (clamped between 10ms and 100ms)
    this.delta_t = Math.max(0.01, Math.min(0.1, elapsed / 1000));
    //-----------------------------------------------------------------------
    
    // Is speedFactor change
    const newDelta_t = this.delta_t * this.speedFactor;
    
    // Update helicopter position and rotation
    if (this.helicopter) {
      this.helicopter.update(newDelta_t);
    }
    
    // Call checkKeys to process user input
    this.checkKeys();
  }


  checkKeys() {
    var text = "Keys pressed: ";
    var keysPressed = false;    // Check for key codes e.g. in https://keycode.info/
    
    // W/S keys control forward movement and braking
    if (this.gui.isKeyPressed("KeyW")) {
      this.helicopter.accelerate(this.acceleration * this.speedFactor);
      text += " W ";
      keysPressed = true;
    }

    if (this.gui.isKeyPressed("KeyS")) {
      this.helicopter.accelerate(-this.acceleration * this.speedFactor);
      text += " S ";
      keysPressed = true;
    }
    
    // A/D keys for rotation (left/right)
    if (this.gui.isKeyPressed("KeyA")) {
      this.helicopter.turn(this.rotationSpeed * this.delta_t * this.speedFactor);
      text += " A ";
      keysPressed = true;
    }
    
    if (this.gui.isKeyPressed("KeyD")) {
      this.helicopter.turn(-this.rotationSpeed * this.delta_t * this.speedFactor);
      text += " D ";
      keysPressed = true;
    }
    
    // Reset
    if (this.gui.isKeyPressed("KeyR")) {
      this.helicopter.reset();
      text += " R ";
      keysPressed = true;
    }
    
    // Up
    if (this.gui.isKeyPressed("KeyP")) {
      this.helicopter.takeOff();
      text += " P ";
      keysPressed = true;
    }
    
    // Down or Return to Helipad 
    if (this.gui.isKeyPressed("KeyL")) {
      this.helicopter.land();
      text += " L ";
      keysPressed = true;
    }
    
    // Release water over fire
    if (this.gui.isKeyPressed("KeyO")) {
      if (this.helicopter.hasWater && this.helicopter.isOverFire()) {
        this.helicopter.releaseWater();
        this.extinguishFire();
        text += " O ";
        keysPressed = true;
      }
    }
    
    if (keysPressed)
      console.log(text);
  }  

  
  extinguishFire() {
    const fireOffset = 7;
    const fires = [
      { x: 130 + fireOffset, z: 120 + fireOffset, rotation: -Math.PI/2, displayFlag: 'displayFire1' }, // Fire 1 center
      { x: 100 + fireOffset, z: 80 + fireOffset, rotation: 0, displayFlag: 'displayFire2' },           // Fire 2 center
      { x: 160 + fireOffset, z: 50 + fireOffset, rotation: Math.PI/3, displayFlag: 'displayFire3' }    // Fire 3 center
    ];
    
    const fireSize = 14;
    const fireRadius = fireSize / 2;
    
    // check which fire the helicopter is over and schedule delayed extinguishing
    for (let fire of fires) {

      // Skip if fire is already extinguished
      if (!this[fire.displayFlag]) {
        continue;
      }
      
      let relativeX = this.helicopter.x - fire.x;
      let relativeZ = this.helicopter.z - fire.z;
      
      // apply inverse rotation to account for fire rotation
      if (fire.rotation !== 0) {
        let cosRot = Math.cos(-fire.rotation);
        let sinRot = Math.sin(-fire.rotation);
        let rotatedX = relativeX * cosRot - relativeZ * sinRot;
        let rotatedZ = relativeX * sinRot + relativeZ * cosRot;
        relativeX = rotatedX;
        relativeZ = rotatedZ;
      }
        
      // check if helicopter is within fire bounds
      if (Math.abs(relativeX) <= fireRadius && Math.abs(relativeZ) <= fireRadius) {
        if (this.helicopter.y <= 120) {

          const dropHeight = this.helicopter.y - 15;
          const dropFallTime = dropHeight / 40;
          const delayMs = Math.max(dropFallTime * 1000, 1500);
          
          setTimeout(() => {
            this[fire.displayFlag] = false;
            console.log(`${fire.displayFlag} extinguished by water!`);
          }, delayMs);
          
          return;
        }
      }
    }
  }

  setDefaultAppearance() {
    this.setAmbient(0.5, 0.5, 0.5, 1.0);
    this.setDiffuse(0.5, 0.5, 0.5, 1.0);
    this.setSpecular(0.5, 0.5, 0.5, 1.0);
    this.setShininess(10.0);
  }


  display() {
    // ---- BEGIN Background, camera and axis setup
    // Clear image and depth buffer everytime we update the scene
    this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
    // Initialize Model-View matrix as identity (no transformation
    this.updateProjectionMatrix();
    this.loadIdentity();
    // Apply transformations corresponding to the camera position relative to the origin
    this.applyViewMatrix();
    
    this.lights[0].update();

    // Draw axis
    this.setDefaultAppearance();
    if (this.displayAxis) this.axis.display();
    this.setDefaultAppearance();

    if (this.displayForest){
      this.pushMatrix();
      this.translate(195, 0, 6);
      this.rotate((-Math.PI / 2), 0, 1, 0);
      this.forest.display();
      this.popMatrix();
    }

    this.grass.apply();
    this.pushMatrix();
    this.scale(400, 1, 400);
    this.rotate(-Math.PI / 2, 1, 0, 0);
    if (this.displayPlane)this.plane.display();
    this.popMatrix();

    if (this.displayLake) {
      this.pushMatrix();
      this.translate(-110, 0.95, 115);
      this.rotate((-Math.PI / 2), 1, 0, 0);
      this.rotate((-Math.PI / 4), 0, 0, 1);
      this.scale(8.5, 8.5, 8.5);
      this.lake.display();
      this.popMatrix();
    }  
    
    if (this.displayHelicopter){
      this.debug.apply();
      this.pushMatrix();
      this.helicopter.display();
      this.popMatrix();
    }

    if (this.displayBuilding){
      this.pushMatrix();
      this.translate(0, 0, -140);
      this.building.display();
      this.popMatrix();
    }

    if (this.displayPanorama){ 
      this.setActiveShader(this.panorama.cloudShader);
      this.panorama.display();
      this.setDefaultAppearance();
    }  

    if (this.displayFire1 || this.displayFire2 || this.displayFire3) {
      this.setActiveShader(this.fire.flameShader);
      
      if (this.displayFire1){ 
        this.pushMatrix();
        this.translate(130, 0, 120);
        this.rotate((-Math.PI / 2), 0, 1, 0);
        this.fire.display();
        this.popMatrix();
      }

      if (this.displayFire2){ 
        this.pushMatrix();
        this.translate(100, 0, 80);
        this.fire.display();
        this.popMatrix();
      }

      if (this.displayFire3){ 
        this.pushMatrix();
        this.translate(160, 0, 50);
        this.rotate((Math.PI / 3), 0, 1, 0);
        this.fire.display();
        this.popMatrix();
      }
      
      this.setActiveShader(this.defaultShader);
    }
    else {
      this.setActiveShader(this.defaultShader);
    }
  }
}
